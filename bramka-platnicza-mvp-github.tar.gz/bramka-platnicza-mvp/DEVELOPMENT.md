# 🔧 Przewodnik developera

## Architektura systemu

### Frontend (React + Vite)
```
src/
├── components/          # Reusable components
│   ├── PaymentMethods.jsx
│   ├── QRGenerator.jsx
│   └── OrganizationModal.jsx
├── pages/              # Page components
│   ├── HomePage.jsx
│   ├── DonationPage.jsx
│   ├── AdminDashboard.jsx
│   └── OrganizationRegistration.jsx
├── utils/              # Utilities
│   └── mockData.js
├── App.jsx             # Main app component
└── main.jsx            # Entry point
```

### Backend (FastAPI)
```
app/
├── routes/             # API endpoints
│   ├── organizations.py
│   ├── payments.py
│   ├── registration.py
│   └── admin.py
├── data/               # JSON storage
│   ├── organizations.json
│   ├── payments.json
│   └── organization_registrations.json
├── utils/              # Backend utilities
│   ├── storage.py
│   └── mock_autopay.py
├── models.py           # Pydantic models
└── __init__.py
```

## Modele danych

### Organization
```python
class Organization(BaseModel):
    id: str
    name: str
    description: str
    category: str
    location: str
    target_amount: float
    collected_amount: float = 0.0
    contact_email: EmailStr
    contact_phone: str
    contact_person: str
    website: Optional[str] = None
    status: str = "active"
    created_at: datetime
    updated_at: datetime
```

### Payment
```python
class Payment(BaseModel):
    id: str
    organization_id: str
    amount: float
    method: str  # card, blik, apple_pay, google_pay
    status: str  # pending, completed, failed
    donor_email: EmailStr
    transaction_id: Optional[str] = None
    autopay_payment_id: Optional[str] = None
    created_at: datetime
    updated_at: datetime
```

### OrganizationRegistration
```python
class OrganizationRegistration(BaseModel):
    id: str
    name: str
    description: str
    category: str
    location: str
    target_amount: float
    contact_email: EmailStr
    contact_phone: str
    contact_person: str
    legal_name: str
    tax_id: str
    registration_number: str
    address: str
    bank_account: str
    bank_name: str
    website: Optional[str] = None
    status: str = "pending"  # pending, verification_sent, verified, rejected
    verification_reference: Optional[str] = None
    created_at: datetime
    updated_at: datetime
```

## API Endpoints

### Organizations
- `GET /api/organizations` - Lista organizacji
- `GET /api/organizations/{id}` - Szczegóły organizacji
- `GET /api/organizations/{id}/stats` - Statystyki organizacji
- `GET /api/organizations/{id}/payments` - Płatności organizacji
- `POST /api/organizations` - Dodaj organizację (admin)
- `PUT /api/organizations/{id}` - Edytuj organizację (admin)
- `DELETE /api/organizations/{id}` - Usuń organizację (admin)

### Payments
- `POST /api/payments/initiate` - Inicjuj płatność
- `GET /api/payments/{id}/status` - Status płatności
- `GET /api/payments` - Lista płatności (admin)
- `POST /api/payments/webhook` - Webhook Autopay

### Organization Registration
- `POST /api/org/register` - Rejestracja organizacji
- `GET /api/org/registration/{id}/status` - Status rejestracji
- `POST /api/org/registration/{id}/simulate-payment` - Symulacja płatności weryfikacyjnej
- `GET /api/org/registrations` - Lista rejestracji (admin)
- `PUT /api/org/registration/{id}/admin-action` - Akcje admin na rejestracji

### Admin
- `GET /api/admin/config` - Konfiguracja API
- `PUT /api/admin/config` - Aktualizuj konfigurację
- `POST /api/admin/test-autopay` - Test połączenia Autopay
- `GET /api/stats` - Globalne statystyki

## Komponenty React

### PaymentMethods
Komponent wyboru metody płatności z animacjami:
```jsx
const PaymentMethods = ({ selectedMethod, onMethodSelect }) => {
  const methods = [
    { id: 'card', name: 'Karta płatnicza', icon: CreditCard },
    { id: 'blik', name: 'BLIK', icon: Smartphone },
    { id: 'apple_pay', name: 'Apple Pay', icon: Apple },
    { id: 'google_pay', name: 'Google Pay', icon: Chrome }
  ];
  
  return (
    <div className="grid grid-cols-2 gap-4">
      {methods.map(method => (
        <PaymentMethodCard 
          key={method.id}
          method={method}
          selected={selectedMethod === method.id}
          onSelect={() => onMethodSelect(method.id)}
        />
      ))}
    </div>
  );
};
```

### QRGenerator
Generator kodów QR z możliwością pobrania:
```jsx
const QRGenerator = ({ url, organizationName }) => {
  const [qrDataUrl, setQrDataUrl] = useState('');
  
  useEffect(() => {
    QRCode.toDataURL(url, { width: 256 }, (err, dataUrl) => {
      if (!err) setQrDataUrl(dataUrl);
    });
  }, [url]);
  
  const downloadQR = () => {
    const link = document.createElement('a');
    link.download = `qr-${organizationName}.png`;
    link.href = qrDataUrl;
    link.click();
  };
  
  return (
    <div className="text-center">
      <img src={qrDataUrl} alt="QR Code" className="mx-auto" />
      <button onClick={downloadQR}>Pobierz QR</button>
    </div>
  );
};
```

## Storage System

### JSON Storage
Prosty system przechowywania danych w plikach JSON:

```python
class JSONStorage:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.lock = threading.Lock()
    
    def read_all(self) -> List[Dict]:
        with self.lock:
            if not os.path.exists(self.file_path):
                return []
            with open(self.file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    
    def write_all(self, data: List[Dict]) -> None:
        with self.lock:
            os.makedirs(os.path.dirname(self.file_path), exist_ok=True)
            with open(self.file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False, default=str)
    
    def create(self, item: Dict) -> Dict:
        data = self.read_all()
        item['id'] = str(uuid.uuid4())
        item['created_at'] = datetime.now()
        item['updated_at'] = datetime.now()
        data.append(item)
        self.write_all(data)
        return item
```

## Mock Autopay Integration

### Symulacja API Autopay
```python
class MockAutopayAPI:
    @staticmethod
    async def create_payment(amount: float, description: str, return_url: str) -> Dict:
        # Symulacja opóźnienia API
        await asyncio.sleep(2)
        
        # 90% szans na sukces
        success = random.random() < 0.9
        
        payment_id = f"pay_{uuid.uuid4().hex[:12]}"
        
        if success:
            return {
                "payment_id": payment_id,
                "status": "completed",
                "amount": amount,
                "currency": "PLN",
                "payment_url": f"https://autopay.pl/pay/{payment_id}"
            }
        else:
            return {
                "payment_id": payment_id,
                "status": "failed",
                "error": "Insufficient funds"
            }
    
    @staticmethod
    async def get_payment_status(payment_id: str) -> Dict:
        await asyncio.sleep(1)
        return {
            "payment_id": payment_id,
            "status": "completed",
            "amount": 100.0,
            "currency": "PLN"
        }
```

## Styling z Tailwind CSS

### Custom Theme
```javascript
// tailwind.config.js
module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eff6ff',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
        }
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-out',
        'pulse-slow': 'pulse 3s infinite',
      }
    }
  }
}
```

### Custom Components
```css
/* index.css */
@layer components {
  .btn-primary {
    @apply px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors duration-200;
  }
  
  .card {
    @apply bg-gray-800 rounded-lg border border-gray-700 p-6;
  }
  
  .input-field {
    @apply w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500;
  }
}
```

## Testing

### Frontend Tests (Jest + React Testing Library)
```javascript
// PaymentMethods.test.jsx
import { render, screen, fireEvent } from '@testing-library/react';
import PaymentMethods from '../components/PaymentMethods';

test('renders payment methods', () => {
  const mockOnSelect = jest.fn();
  render(<PaymentMethods selectedMethod="" onMethodSelect={mockOnSelect} />);
  
  expect(screen.getByText('Karta płatnicza')).toBeInTheDocument();
  expect(screen.getByText('BLIK')).toBeInTheDocument();
});

test('calls onMethodSelect when method is clicked', () => {
  const mockOnSelect = jest.fn();
  render(<PaymentMethods selectedMethod="" onMethodSelect={mockOnSelect} />);
  
  fireEvent.click(screen.getByText('Karta płatnicza'));
  expect(mockOnSelect).toHaveBeenCalledWith('card');
});
```

### Backend Tests (pytest)
```python
# test_organizations.py
import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_get_organizations():
    response = client.get("/api/organizations")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_create_organization():
    org_data = {
        "name": "Test Organization",
        "description": "Test description",
        "category": "test",
        "location": "Test City",
        "target_amount": 10000,
        "contact_email": "test@example.com",
        "contact_phone": "+48123456789",
        "contact_person": "Test Person"
    }
    response = client.post("/api/organizations", json=org_data)
    assert response.status_code == 200
    assert response.json()["name"] == "Test Organization"
```

## Performance Optimization

### Frontend
- **Code splitting** - lazy loading komponentów
- **Image optimization** - WebP format, lazy loading
- **Bundle analysis** - webpack-bundle-analyzer
- **Caching** - service workers, browser cache

### Backend
- **Database indexing** - indeksy na często używanych polach
- **Caching** - Redis dla często używanych danych
- **Connection pooling** - optymalizacja połączeń DB
- **Background tasks** - Celery dla długich operacji

## Security Best Practices

### Frontend
- **Input validation** - walidacja po stronie klienta
- **XSS protection** - sanityzacja danych
- **CSRF protection** - tokeny CSRF
- **Content Security Policy** - CSP headers

### Backend
- **Input validation** - Pydantic models
- **SQL injection protection** - parametryzowane zapytania
- **Rate limiting** - ograniczenie żądań
- **Authentication** - JWT tokens
- **HTTPS only** - wymuszenie szyfrowania

## Monitoring i Debugging

### Logging
```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    
    logger.info(
        f"{request.method} {request.url} - "
        f"Status: {response.status_code} - "
        f"Time: {process_time:.4f}s"
    )
    return response
```

### Error Handling
```python
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Global exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"}
    )
```

## Migracja do prawdziwego Autopay

### 1. Zastąpienie mock API
```python
# real_autopay.py
import httpx
from app.routes.admin import load_config

class AutopayAPI:
    def __init__(self):
        self.config = load_config()
        self.base_url = (
            "https://api.autopay.pl" if self.config.is_live_mode 
            else "https://sandbox-api.autopay.pl"
        )
    
    async def create_payment(self, amount: float, description: str, return_url: str):
        headers = {
            "Authorization": f"Bearer {self.config.autopay_api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "amount": amount,
            "currency": "PLN",
            "description": description,
            "return_url": return_url,
            "merchant_id": self.config.autopay_merchant_id
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/payments", 
                json=payload, 
                headers=headers
            )
            return response.json()
```

### 2. Webhook handling
```python
@router.post("/webhook")
async def autopay_webhook(request: Request):
    # Walidacja podpisu
    signature = request.headers.get("X-Autopay-Signature")
    payload = await request.body()
    
    if not validate_webhook_signature(payload, signature):
        raise HTTPException(status_code=400, detail="Invalid signature")
    
    # Przetwarzanie webhook
    data = json.loads(payload)
    payment_id = data.get("payment_id")
    status = data.get("status")
    
    # Aktualizacja statusu płatności
    await update_payment_status(payment_id, status)
    
    return {"status": "ok"}
```

