from fastapi import APIRouter, HTTPException, Query, Depends
from typing import List, Optional
from datetime import datetime
import uuid

from app.models import (
    Organization, OrganizationCreate, OrganizationUpdate, 
    OrganizationStats, APIResponse
)
from app.utils.storage import (
    get_organizations, get_organization_by_id, create_organization,
    update_organization, get_payments_by_organization
)

router = APIRouter()

@router.get("/organizations", response_model=List[Organization])
async def list_organizations(
    category: Optional[str] = Query(None, description="Filtruj po kategorii"),
    location: Optional[str] = Query(None, description="Filtruj po lokalizacji"),
    limit: int = Query(10, ge=1, le=100, description="Limit wyników"),
    offset: int = Query(0, ge=0, description="Offset dla paginacji")
):
    """
    Pobiera listę wszystkich organizacji z opcjonalnymi filtrami.
    """
    try:
        organizations = await get_organizations()
        
        # Filtrowanie
        if category:
            organizations = [org for org in organizations if org.get('category') == category]
        
        if location:
            organizations = [org for org in organizations if location.lower() in org.get('location', '').lower()]
        
        # Sortowanie po collected_amount (malejąco)
        organizations.sort(key=lambda x: x.get('collected_amount', 0), reverse=True)
        
        # Paginacja
        total = len(organizations)
        organizations = organizations[offset:offset + limit]
        
        return organizations
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd pobierania organizacji: {str(e)}")

@router.get("/organizations/{organization_id}", response_model=Organization)
async def get_organization(organization_id: str):
    """
    Pobiera szczegóły konkretnej organizacji.
    """
    try:
        organization = await get_organization_by_id(organization_id)
        
        if not organization:
            raise HTTPException(
                status_code=404, 
                detail=f"Organizacja o ID '{organization_id}' nie została znaleziona"
            )
        
        return organization
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd pobierania organizacji: {str(e)}")

@router.post("/organizations", response_model=APIResponse)
async def create_new_organization(organization: OrganizationCreate):
    """
    Tworzy nową organizację (endpoint administracyjny).
    """
    try:
        # Generuj unikalny ID
        org_id = f"org_{uuid.uuid4().hex[:12]}"
        
        # Sprawdź czy organizacja o takiej nazwie już istnieje
        existing_orgs = await get_organizations()
        if any(org.get('name', '').lower() == organization.name.lower() for org in existing_orgs):
            raise HTTPException(
                status_code=400,
                detail="Organizacja o takiej nazwie już istnieje"
            )
        
        # Przygotuj dane organizacji
        org_data = {
            "id": org_id,
            **organization.dict(),
            "collected_amount": 0.0,
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat()
        }
        
        # Zapisz organizację
        success = await create_organization(org_data)
        
        if not success:
            raise HTTPException(
                status_code=500,
                detail="Nie udało się utworzyć organizacji"
            )
        
        return APIResponse(
            success=True,
            message="Organizacja została pomyślnie utworzona",
            data={"organization_id": org_id}
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd tworzenia organizacji: {str(e)}")

@router.put("/organizations/{organization_id}", response_model=APIResponse)
async def update_organization_details(organization_id: str, updates: OrganizationUpdate):
    """
    Aktualizuje dane organizacji (endpoint administracyjny).
    """
    try:
        # Sprawdź czy organizacja istnieje
        existing_org = await get_organization_by_id(organization_id)
        if not existing_org:
            raise HTTPException(
                status_code=404,
                detail=f"Organizacja o ID '{organization_id}' nie została znaleziona"
            )
        
        # Przygotuj dane do aktualizacji (tylko niepuste pola)
        update_data = {k: v for k, v in updates.dict().items() if v is not None}
        
        if not update_data:
            raise HTTPException(
                status_code=400,
                detail="Brak danych do aktualizacji"
            )
        
        # Aktualizuj organizację
        success = await update_organization(organization_id, update_data)
        
        if not success:
            raise HTTPException(
                status_code=500,
                detail="Nie udało się zaktualizować organizacji"
            )
        
        return APIResponse(
            success=True,
            message="Organizacja została pomyślnie zaktualizowana"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd aktualizacji organizacji: {str(e)}")

@router.get("/organizations/{organization_id}/stats", response_model=OrganizationStats)
async def get_organization_statistics(organization_id: str):
    """
    Pobiera statystyki dla konkretnej organizacji.
    """
    try:
        # Sprawdź czy organizacja istnieje
        organization = await get_organization_by_id(organization_id)
        if not organization:
            raise HTTPException(
                status_code=404,
                detail=f"Organizacja o ID '{organization_id}' nie została znaleziona"
            )
        
        # Pobierz płatności dla organizacji
        payments = await get_payments_by_organization(organization_id)
        completed_payments = [p for p in payments if p.get('status') == 'completed']
        
        # Oblicz statystyki
        total_amount = sum(p.get('amount', 0) for p in completed_payments)
        payment_count = len(completed_payments)
        avg_payment = total_amount / payment_count if payment_count > 0 else 0
        
        # Znajdź ostatnią płatność
        last_payment = None
        if completed_payments:
            last_payment_data = max(
                completed_payments, 
                key=lambda x: datetime.fromisoformat(x.get('created_at', '').replace('Z', '+00:00'))
            )
            last_payment = datetime.fromisoformat(
                last_payment_data.get('created_at', '').replace('Z', '+00:00')
            )
        
        return OrganizationStats(
            total_amount=total_amount,
            payment_count=payment_count,
            avg_payment=avg_payment,
            last_payment=last_payment
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd pobierania statystyk: {str(e)}")

@router.get("/organizations/{organization_id}/payments")
async def get_organization_payments(
    organization_id: str,
    status: Optional[str] = Query(None, description="Filtruj po statusie płatności"),
    limit: int = Query(10, ge=1, le=100, description="Limit wyników"),
    offset: int = Query(0, ge=0, description="Offset dla paginacji")
):
    """
    Pobiera płatności dla konkretnej organizacji.
    """
    try:
        # Sprawdź czy organizacja istnieje
        organization = await get_organization_by_id(organization_id)
        if not organization:
            raise HTTPException(
                status_code=404,
                detail=f"Organizacja o ID '{organization_id}' nie została znaleziona"
            )
        
        # Pobierz płatności
        payments = await get_payments_by_organization(organization_id)
        
        # Filtrowanie po statusie
        if status:
            payments = [p for p in payments if p.get('status') == status]
        
        # Sortowanie po dacie (najnowsze pierwsze)
        payments.sort(
            key=lambda x: datetime.fromisoformat(x.get('created_at', '').replace('Z', '+00:00')), 
            reverse=True
        )
        
        # Paginacja
        total = len(payments)
        payments = payments[offset:offset + limit]
        
        return {
            "payments": payments,
            "total": total,
            "page": offset // limit + 1,
            "size": limit,
            "pages": (total + limit - 1) // limit
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd pobierania płatności: {str(e)}")


@router.delete("/organizations/{organization_id}", response_model=APIResponse)
async def delete_organization(organization_id: str):
    """
    Usuwa organizację (endpoint administracyjny).
    """
    try:
        # Sprawdź czy organizacja istnieje
        existing_org = await get_organization_by_id(organization_id)
        if not existing_org:
            raise HTTPException(
                status_code=404,
                detail=f"Organizacja o ID '{organization_id}' nie została znaleziona"
            )
        
        # Sprawdź czy organizacja ma płatności
        payments = await get_payments_by_organization(organization_id)
        if payments:
            raise HTTPException(
                status_code=400,
                detail="Nie można usunąć organizacji, która ma płatności. Najpierw usuń wszystkie płatności."
            )
        
        # Usuń organizację z pliku JSON
        from app.utils.storage import delete_organization
        success = await delete_organization(organization_id)
        
        if not success:
            raise HTTPException(
                status_code=500,
                detail="Nie udało się usunąć organizacji"
            )
        
        return APIResponse(
            success=True,
            message="Organizacja została pomyślnie usunięta"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd usuwania organizacji: {str(e)}")

