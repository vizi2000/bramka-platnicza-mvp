from fastapi import APIRouter, HTTPException, Depends
from typing import List, Optional
from datetime import datetime, timedelta
import uuid
import random
import string

from app.models import (
    OrganizationRegistration, OrganizationRegistrationResponse, 
    OrganizationVerificationStatus, VerificationPayment,
    OrganizationDashboard, OrganizationStatus, APIResponse
)
from app.utils.storage import (
    create_organization_registration, get_organization_registration_by_id,
    update_organization_registration_status, get_organization_registrations,
    create_verification_payment, get_verification_payment_by_registration_id
)

router = APIRouter()

def generate_reference_number() -> str:
    """Generuje unikalny numer referencyjny dla przelewu weryfikacyjnego."""
    return f"VER{random.randint(100000, 999999)}"

def generate_payment_title(registration_id: str, reference_number: str) -> str:
    """Generuje tytuł przelewu weryfikacyjnego."""
    return f"Weryfikacja organizacji {registration_id[:8]} REF:{reference_number}"

@router.post("/register", response_model=OrganizationRegistrationResponse)
async def register_organization(registration: OrganizationRegistration):
    """
    Rejestruje nową organizację i inicjuje proces weryfikacji.
    """
    try:
        # Generuj unikalny ID rejestracji
        registration_id = f"reg_{uuid.uuid4().hex[:12]}"
        
        # Sprawdź czy organizacja o takiej nazwie lub NIP już istnieje
        existing_registrations = await get_organization_registrations()
        
        # Sprawdź nazwę
        if any(reg.get('name', '').lower() == registration.name.lower() for reg in existing_registrations):
            raise HTTPException(
                status_code=400,
                detail="Organizacja o takiej nazwie już istnieje lub jest w trakcie rejestracji"
            )
        
        # Sprawdź NIP
        if any(reg.get('tax_id') == registration.tax_id for reg in existing_registrations):
            raise HTTPException(
                status_code=400,
                detail="Organizacja o takim NIP już istnieje lub jest w trakcie rejestracji"
            )
        
        # Sprawdź email
        if any(reg.get('contact_email') == registration.contact_email for reg in existing_registrations):
            raise HTTPException(
                status_code=400,
                detail="Organizacja o takim adresie email już istnieje lub jest w trakcie rejestracji"
            )
        
        # Przygotuj dane rejestracji
        registration_data = {
            "id": registration_id,
            **registration.dict(),
            "status": OrganizationStatus.PENDING,
            "submitted_at": datetime.utcnow().isoformat(),
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat()
        }
        
        # Zapisz rejestrację
        success = await create_organization_registration(registration_data)
        
        if not success:
            raise HTTPException(
                status_code=500,
                detail="Nie udało się zapisać rejestracji organizacji"
            )
        
        # Generuj dane do weryfikacji płatności
        reference_number = generate_reference_number()
        payment_title = generate_payment_title(registration_id, reference_number)
        
        verification_payment = VerificationPayment(
            registration_id=registration_id,
            amount=1.0,
            bank_account=registration.bank_account,
            reference_number=reference_number,
            payment_title=payment_title,
            autopay_account="PL12345678901234567890123456",  # Mock konto Autopay
            instructions=f"""
Aby zweryfikować swoją organizację, wykonaj przelew weryfikacyjny:

1. Kwota: 1,00 PLN
2. Na konto: PL12345678901234567890123456
3. Tytuł: {payment_title}
4. Z konta organizacji: {registration.bank_account}

WAŻNE:
- Przelew musi być wykonany z konta bankowego organizacji
- Tytuł przelewu musi być dokładnie taki jak podano
- Weryfikacja może potrwać 1-3 dni robocze
- Po weryfikacji otrzymasz email z potwierdzeniem

Numer referencyjny: {reference_number}
            """.strip()
        )
        
        # Zapisz dane weryfikacji
        await create_verification_payment(verification_payment.dict())
        
        # Aktualizuj status na "verification_sent"
        await update_organization_registration_status(
            registration_id, 
            OrganizationStatus.VERIFICATION_SENT
        )
        
        return OrganizationRegistrationResponse(
            registration_id=registration_id,
            status=OrganizationStatus.VERIFICATION_SENT,
            message="Rejestracja została przyjęta. Sprawdź email z instrukcjami weryfikacji.",
            verification_instructions={
                "payment_amount": 1.0,
                "payment_account": "PL12345678901234567890123456",
                "payment_title": payment_title,
                "reference_number": reference_number,
                "from_account": registration.bank_account
            },
            estimated_verification_time="1-3 dni robocze"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd rejestracji organizacji: {str(e)}")

@router.get("/registration/{registration_id}/status", response_model=OrganizationVerificationStatus)
async def get_registration_status(registration_id: str):
    """
    Pobiera status rejestracji organizacji.
    """
    try:
        # Pobierz rejestrację
        registration = await get_organization_registration_by_id(registration_id)
        if not registration:
            raise HTTPException(
                status_code=404,
                detail=f"Rejestracja o ID '{registration_id}' nie została znaleziona"
            )
        
        # Pobierz dane weryfikacji płatności
        verification_payment = await get_verification_payment_by_registration_id(registration_id)
        
        return OrganizationVerificationStatus(
            registration_id=registration_id,
            status=registration.get('status'),
            submitted_at=datetime.fromisoformat(registration.get('submitted_at')),
            verified_at=datetime.fromisoformat(registration.get('verified_at')) if registration.get('verified_at') else None,
            verification_payment=VerificationPayment(**verification_payment) if verification_payment else None,
            admin_notes=registration.get('admin_notes'),
            organization_id=registration.get('organization_id')
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd pobierania statusu: {str(e)}")

@router.post("/registration/{registration_id}/simulate-payment", response_model=APIResponse)
async def simulate_verification_payment(registration_id: str):
    """
    Symuluje otrzymanie przelewu weryfikacyjnego (mock Autopay).
    W prawdziwej implementacji byłby to webhook od Autopay.
    """
    try:
        # Pobierz rejestrację
        registration = await get_organization_registration_by_id(registration_id)
        if not registration:
            raise HTTPException(
                status_code=404,
                detail=f"Rejestracja o ID '{registration_id}' nie została znaleziona"
            )
        
        if registration.get('status') != OrganizationStatus.VERIFICATION_SENT:
            raise HTTPException(
                status_code=400,
                detail="Rejestracja nie jest w statusie oczekiwania na weryfikację"
            )
        
        # Symuluj weryfikację (90% szans na sukces)
        verification_success = random.random() < 0.9
        
        if verification_success:
            # Aktualizuj status na "verified"
            await update_organization_registration_status(
                registration_id, 
                OrganizationStatus.VERIFIED,
                admin_notes="Przelew weryfikacyjny otrzymany i zweryfikowany automatycznie",
                verified_at=datetime.utcnow().isoformat()
            )
            
            # W prawdziwej implementacji tutaj utworzylibyśmy organizację
            # i przenieśli dane z rejestracji
            
            return APIResponse(
                success=True,
                message="Przelew weryfikacyjny został otrzymany. Organizacja została zweryfikowana!",
                data={
                    "status": OrganizationStatus.VERIFIED,
                    "verified_at": datetime.utcnow().isoformat()
                }
            )
        else:
            # Symuluj błąd weryfikacji
            await update_organization_registration_status(
                registration_id,
                OrganizationStatus.REJECTED,
                admin_notes="Błąd weryfikacji przelewu - nieprawidłowy tytuł lub konto nadawcy"
            )
            
            return APIResponse(
                success=False,
                message="Weryfikacja nie powiodła się. Sprawdź dane przelewu i spróbuj ponownie.",
                data={
                    "status": OrganizationStatus.REJECTED,
                    "error": "Nieprawidłowe dane przelewu"
                }
            )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd symulacji płatności: {str(e)}")

@router.get("/registration/{registration_id}/dashboard", response_model=OrganizationDashboard)
async def get_organization_dashboard(registration_id: str):
    """
    Pobiera dashboard organizacji z pełnymi informacjami.
    """
    try:
        # Pobierz rejestrację
        registration = await get_organization_registration_by_id(registration_id)
        if not registration:
            raise HTTPException(
                status_code=404,
                detail=f"Rejestracja o ID '{registration_id}' nie została znaleziona"
            )
        
        # Pobierz status weryfikacji
        verification_status = await get_registration_status(registration_id)
        
        # Pobierz dane weryfikacji płatności
        verification_payment = await get_verification_payment_by_registration_id(registration_id)
        
        # Przygotuj response rejestracji
        registration_response = OrganizationRegistrationResponse(
            registration_id=registration_id,
            status=registration.get('status'),
            message=f"Status: {registration.get('status')}",
            verification_instructions={
                "payment_amount": 1.0,
                "reference_number": verification_payment.get('reference_number') if verification_payment else None
            } if verification_payment else None
        )
        
        dashboard = OrganizationDashboard(
            registration=registration_response,
            verification_status=verification_status,
            organization=None,  # TODO: Po implementacji tworzenia organizacji
            payments_summary=None  # TODO: Po implementacji
        )
        
        return dashboard
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd pobierania dashboard: {str(e)}")

@router.get("/registrations", response_model=List[dict])
async def list_organization_registrations(
    status: Optional[OrganizationStatus] = None,
    limit: int = 50
):
    """
    Pobiera listę rejestracji organizacji (endpoint administracyjny).
    """
    try:
        registrations = await get_organization_registrations()
        
        # Filtrowanie po statusie
        if status:
            registrations = [reg for reg in registrations if reg.get('status') == status]
        
        # Sortowanie po dacie (najnowsze pierwsze)
        registrations.sort(
            key=lambda x: datetime.fromisoformat(x.get('submitted_at', '')), 
            reverse=True
        )
        
        # Limit
        registrations = registrations[:limit]
        
        return registrations
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd pobierania rejestracji: {str(e)}")

@router.put("/registration/{registration_id}/admin-action", response_model=APIResponse)
async def admin_update_registration_status(
    registration_id: str,
    status: OrganizationStatus,
    admin_notes: Optional[str] = None
):
    """
    Aktualizuje status rejestracji (endpoint administracyjny).
    """
    try:
        # Sprawdź czy rejestracja istnieje
        registration = await get_organization_registration_by_id(registration_id)
        if not registration:
            raise HTTPException(
                status_code=404,
                detail=f"Rejestracja o ID '{registration_id}' nie została znaleziona"
            )
        
        # Aktualizuj status
        verified_at = datetime.utcnow().isoformat() if status == OrganizationStatus.VERIFIED else None
        
        success = await update_organization_registration_status(
            registration_id,
            status,
            admin_notes=admin_notes,
            verified_at=verified_at
        )
        
        if not success:
            raise HTTPException(
                status_code=500,
                detail="Nie udało się zaktualizować statusu rejestracji"
            )
        
        return APIResponse(
            success=True,
            message=f"Status rejestracji został zaktualizowany na: {status}",
            data={
                "registration_id": registration_id,
                "new_status": status,
                "admin_notes": admin_notes
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd aktualizacji statusu: {str(e)}")

