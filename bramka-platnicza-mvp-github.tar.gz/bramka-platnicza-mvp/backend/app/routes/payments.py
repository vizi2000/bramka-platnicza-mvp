from fastapi import APIRouter, HTTPException, Query, BackgroundTasks
from typing import List, Optional, Dict
from datetime import datetime
import uuid
import asyncio

from app.models import (
    Payment, PaymentRequest, PaymentResponse, PaymentStatus,
    GlobalStats, APIResponse
)
from app.utils.storage import (
    get_payments, get_payment_by_id, create_payment, update_payment_status,
    get_organization_by_id, update_organization_collected_amount, get_global_stats
)
from app.utils.mock_autopay import initiate_autopay_payment, check_autopay_payment_status

router = APIRouter()

@router.post("/payments/initiate", response_model=PaymentResponse)
async def initiate_payment(payment_request: PaymentRequest, background_tasks: BackgroundTasks):
    """
    Inicjuje nową płatność przez Autopay.
    """
    try:
        # Sprawdź czy organizacja istnieje
        organization = await get_organization_by_id(payment_request.organization_id)
        if not organization:
            raise HTTPException(
                status_code=404,
                detail=f"Organizacja o ID '{payment_request.organization_id}' nie została znaleziona"
            )
        
        # Generuj unikalny ID płatności
        payment_id = f"pay_{uuid.uuid4().hex[:16]}"
        
        # Przygotuj dane płatności
        payment_data = {
            "id": payment_id,
            "organization_id": payment_request.organization_id,
            "amount": payment_request.amount,
            "status": PaymentStatus.PENDING,
            "method": payment_request.method,
            "donor_email": payment_request.donor_email,
            "donor_name": payment_request.donor_name,
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat()
        }
        
        # Zapisz płatność w bazie
        success = await create_payment(payment_data)
        if not success:
            raise HTTPException(
                status_code=500,
                detail="Nie udało się utworzyć płatności"
            )
        
        # Inicjuj płatność w Autopay (mock)
        try:
            autopay_response = await initiate_autopay_payment(
                amount=payment_request.amount,
                description=f"Darowizna dla {organization['name']}",
                return_url=f"http://localhost:5173/success?payment_id={payment_id}",
                notify_url=f"http://localhost:8000/api/payments/webhook",
                customer_email=payment_request.donor_email
            )
            
            # Aktualizuj płatność z danymi z Autopay
            await update_payment_status(
                payment_id, 
                PaymentStatus.PENDING, 
                autopay_response.transaction_id
            )
            
            # Uruchom zadanie w tle do sprawdzania statusu płatności
            background_tasks.add_task(monitor_payment_status, payment_id, autopay_response.transaction_id)
            
            return PaymentResponse(
                payment_id=payment_id,
                status=PaymentStatus.PENDING,
                amount=payment_request.amount,
                organization_id=payment_request.organization_id,
                method=payment_request.method,
                created_at=datetime.utcnow(),
                redirect_url=autopay_response.redirect_url
            )
            
        except Exception as autopay_error:
            # Jeśli Autopay nie działa, oznacz płatność jako nieudaną
            await update_payment_status(payment_id, PaymentStatus.FAILED)
            raise HTTPException(
                status_code=502,
                detail=f"Błąd komunikacji z systemem płatności: {str(autopay_error)}"
            )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd inicjowania płatności: {str(e)}")

@router.get("/payments/{payment_id}/status", response_model=Payment)
async def get_payment_status(payment_id: str):
    """
    Pobiera aktualny status płatności.
    """
    try:
        payment = await get_payment_by_id(payment_id)
        
        if not payment:
            raise HTTPException(
                status_code=404,
                detail=f"Płatność o ID '{payment_id}' nie została znaleziona"
            )
        
        # Jeśli płatność jest w toku, sprawdź status w Autopay
        if payment.get('status') == PaymentStatus.PENDING and payment.get('autopay_transaction_id'):
            try:
                autopay_status = await check_autopay_payment_status(payment['autopay_transaction_id'])
                
                # Aktualizuj status jeśli się zmienił
                new_status = autopay_status.get('status')
                if new_status != payment.get('status'):
                    await update_payment_status(payment_id, new_status)
                    payment['status'] = new_status
                    payment['updated_at'] = datetime.utcnow().isoformat()
                    
                    # Jeśli płatność została zakończona sukcesem, zaktualizuj kwotę organizacji
                    if new_status == PaymentStatus.COMPLETED:
                        await update_organization_collected_amount(
                            payment['organization_id'], 
                            payment['amount']
                        )
                        
            except Exception as e:
                print(f"Błąd sprawdzania statusu w Autopay: {e}")
        
        return payment
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd pobierania statusu płatności: {str(e)}")

@router.get("/payments", response_model=List[Payment])
async def list_payments(
    organization_id: Optional[str] = Query(None, description="Filtruj po organizacji"),
    status: Optional[str] = Query(None, description="Filtruj po statusie"),
    method: Optional[str] = Query(None, description="Filtruj po metodzie płatności"),
    limit: int = Query(10, ge=1, le=100, description="Limit wyników"),
    offset: int = Query(0, ge=0, description="Offset dla paginacji")
):
    """
    Pobiera listę płatności z filtrami (endpoint administracyjny).
    """
    try:
        payments = await get_payments()
        
        # Filtrowanie
        if organization_id:
            payments = [p for p in payments if p.get('organization_id') == organization_id]
        
        if status:
            payments = [p for p in payments if p.get('status') == status]
        
        if method:
            payments = [p for p in payments if p.get('method') == method]
        
        # Sortowanie po dacie (najnowsze pierwsze)
        payments.sort(
            key=lambda x: datetime.fromisoformat(x.get('created_at', '').replace('Z', '+00:00')), 
            reverse=True
        )
        
        # Paginacja
        total = len(payments)
        payments = payments[offset:offset + limit]
        
        return payments
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd pobierania płatności: {str(e)}")

@router.post("/payments/webhook")
async def autopay_webhook(webhook_data: Dict):
    """
    Endpoint do odbierania webhooków od Autopay.
    """
    try:
        transaction_id = webhook_data.get('transaction_id')
        status = webhook_data.get('status')
        
        if not transaction_id or not status:
            raise HTTPException(status_code=400, detail="Nieprawidłowe dane webhook")
        
        # Znajdź płatność po transaction_id
        payments = await get_payments()
        payment = next(
            (p for p in payments if p.get('autopay_transaction_id') == transaction_id), 
            None
        )
        
        if not payment:
            raise HTTPException(
                status_code=404, 
                detail=f"Płatność z transaction_id '{transaction_id}' nie została znaleziona"
            )
        
        # Aktualizuj status płatności
        await update_payment_status(payment['id'], status)
        
        # Jeśli płatność została zakończona sukcesem, zaktualizuj kwotę organizacji
        if status == PaymentStatus.COMPLETED:
            await update_organization_collected_amount(
                payment['organization_id'], 
                payment['amount']
            )
        
        return {"status": "ok", "message": "Webhook processed successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd przetwarzania webhook: {str(e)}")

@router.get("/stats", response_model=GlobalStats)
async def get_statistics():
    """
    Pobiera globalne statystyki systemu.
    """
    try:
        stats = await get_global_stats()
        return GlobalStats(**stats)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd pobierania statystyk: {str(e)}")

# Funkcja pomocnicza do monitorowania statusu płatności
async def monitor_payment_status(payment_id: str, autopay_transaction_id: str):
    """
    Monitoruje status płatności w tle i aktualizuje go automatycznie.
    """
    max_attempts = 10
    attempt = 0
    
    while attempt < max_attempts:
        try:
            await asyncio.sleep(5)  # Sprawdzaj co 5 sekund
            
            # Sprawdź aktualny status płatności
            payment = await get_payment_by_id(payment_id)
            if not payment or payment.get('status') != PaymentStatus.PENDING:
                break  # Płatność już nie jest w toku
            
            # Sprawdź status w Autopay
            autopay_status = await check_autopay_payment_status(autopay_transaction_id)
            new_status = autopay_status.get('status')
            
            if new_status and new_status != PaymentStatus.PENDING:
                # Aktualizuj status
                await update_payment_status(payment_id, new_status)
                
                # Jeśli sukces, zaktualizuj kwotę organizacji
                if new_status == PaymentStatus.COMPLETED:
                    await update_organization_collected_amount(
                        payment['organization_id'], 
                        payment['amount']
                    )
                
                break  # Płatność zakończona
                
        except Exception as e:
            print(f"Błąd monitorowania płatności {payment_id}: {e}")
        
        attempt += 1
    
    # Jeśli po wszystkich próbach płatność nadal pending, oznacz jako failed
    if attempt >= max_attempts:
        try:
            payment = await get_payment_by_id(payment_id)
            if payment and payment.get('status') == PaymentStatus.PENDING:
                await update_payment_status(payment_id, PaymentStatus.FAILED)
        except Exception as e:
            print(f"Błąd oznaczania płatności jako nieudanej: {e}")

