from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any
import json
import os

router = APIRouter()

class APIConfig(BaseModel):
    autopay_api_key: str = ""
    autopay_environment: str = "sandbox"
    autopay_merchant_id: str = ""
    webhook_url: str = ""
    verification_amount: float = 1.0
    is_live_mode: bool = False

CONFIG_FILE = "app/data/api_config.json"

def load_config() -> APIConfig:
    """Ładuje konfigurację API z pliku."""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                data = json.load(f)
                return APIConfig(**data)
        except Exception:
            pass
    return APIConfig()

def save_config(config: APIConfig) -> None:
    """Zapisuje konfigurację API do pliku."""
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config.dict(), f, indent=2)

@router.get("/admin/config")
async def get_api_config():
    """Pobiera aktualną konfigurację API."""
    config = load_config()
    # Maskuj klucz API w odpowiedzi (tylko jeśli istnieje)
    config_dict = config.dict()
    if config_dict["autopay_api_key"] and len(config_dict["autopay_api_key"]) > 8:
        config_dict["autopay_api_key"] = config_dict["autopay_api_key"][:8] + "*" * 20 + config_dict["autopay_api_key"][-4:]
    return config_dict

@router.put("/admin/config")
async def update_api_config(config: APIConfig):
    """Aktualizuje konfigurację API."""
    try:
        # Walidacja podstawowych danych
        if config.autopay_environment not in ["sandbox", "production"]:
            raise HTTPException(status_code=400, detail="Nieprawidłowe środowisko API")
        
        if config.verification_amount <= 0 or config.verification_amount > 10:
            raise HTTPException(status_code=400, detail="Kwota weryfikacji musi być między 0.01 a 10 PLN")
        
        save_config(config)
        return {"success": True, "message": "Konfiguracja została zapisana pomyślnie"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd podczas zapisywania konfiguracji: {str(e)}")

@router.post("/admin/test-autopay")
async def test_autopay_connection():
    """Testuje połączenie z API Autopay."""
    config = load_config()
    
    if not config.autopay_api_key:
        return {
            "status": "error",
            "message": "Brak klucza API. Skonfiguruj klucz API w ustawieniach."
        }
    
    if not config.autopay_merchant_id:
        return {
            "status": "error", 
            "message": "Brak Merchant ID. Skonfiguruj Merchant ID w ustawieniach."
        }
    
    # Mock test - w prawdziwej implementacji tutaj byłoby wywołanie API Autopay
    try:
        # Symulacja testu połączenia
        if config.autopay_environment == "sandbox":
            # Test sandbox
            return {
                "status": "success",
                "message": f"Połączenie z Autopay Sandbox pomyślne!\nMerchant ID: {config.autopay_merchant_id}\nŚrodowisko: {config.autopay_environment}"
            }
        else:
            # Test production
            return {
                "status": "success", 
                "message": f"Połączenie z Autopay Production pomyślne!\nMerchant ID: {config.autopay_merchant_id}\nŚrodowisko: {config.autopay_environment}\n⚠️ UWAGA: To jest środowisko produkcyjne!"
            }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Błąd połączenia z Autopay: {str(e)}"
        }

@router.get("/admin/migration-guide")
async def get_migration_guide():
    """Zwraca przewodnik migracji do prawdziwego API Autopay."""
    return {
        "steps": [
            {
                "title": "1. Przygotowanie konta Autopay",
                "items": [
                    "Zarejestruj się na https://autopay.pl",
                    "Przejdź proces weryfikacji biznesowej", 
                    "Otrzymaj klucze API (sandbox i production)",
                    "Skonfiguruj webhook URL w panelu Autopay"
                ]
            },
            {
                "title": "2. Zmiany w kodzie backend",
                "items": [
                    "Zastąp mock_autopay.py prawdziwymi wywołaniami API",
                    "Dodaj obsługę webhook'ów od Autopay",
                    "Zaimplementuj retry logic dla failed payments",
                    "Dodaj szczegółowe logowanie transakcji"
                ]
            },
            {
                "title": "3. Konfiguracja bezpieczeństwa",
                "items": [
                    "Przenieś klucze API do zmiennych środowiskowych",
                    "Używaj HTTPS dla wszystkich połączeń",
                    "Waliduj podpisy webhook'ów",
                    "Implementuj rate limiting"
                ]
            },
            {
                "title": "4. Testowanie",
                "items": [
                    "Przetestuj wszystkie scenariusze w sandbox",
                    "Sprawdź obsługę błędów i timeout'ów",
                    "Zweryfikuj webhook'i",
                    "Przeprowadź testy obciążeniowe"
                ]
            }
        ],
        "code_changes": {
            "mock_autopay_replacement": """
# Zastąp mock_autopay.py tym kodem:
import requests
from app.routes.admin import load_config

class AutopayAPI:
    def __init__(self):
        self.config = load_config()
        self.base_url = "https://api.autopay.pl" if self.config.is_live_mode else "https://sandbox-api.autopay.pl"
        
    async def create_payment(self, amount: float, description: str, return_url: str):
        headers = {
            "Authorization": f"Bearer {self.config.autopay_api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "amount": amount,
            "currency": "PLN", 
            "description": description,
            "return_url": return_url,
            "merchant_id": self.config.autopay_merchant_id
        }
        
        response = requests.post(f"{self.base_url}/payments", json=payload, headers=headers)
        return response.json()
            """,
            "webhook_handler": """
# Dodaj do routes/payments.py:
@router.post("/webhook")
async def autopay_webhook(request: Request):
    # Waliduj podpis webhook'a
    signature = request.headers.get("X-Autopay-Signature")
    payload = await request.body()
    
    # Sprawdź podpis (implementacja zależna od dokumentacji Autopay)
    if not validate_webhook_signature(payload, signature):
        raise HTTPException(status_code=400, detail="Invalid signature")
    
    # Przetwórz webhook
    data = json.loads(payload)
    payment_id = data.get("payment_id")
    status = data.get("status")
    
    # Aktualizuj status płatności w bazie danych
    update_payment_status(payment_id, status)
    
    return {"status": "ok"}
            """
        }
    }

