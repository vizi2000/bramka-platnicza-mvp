from pydantic import BaseModel, EmailStr, Field
from typing import Optional, Literal
from datetime import datetime
from enum import Enum

class PaymentStatus(str, Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class PaymentMethod(str, Enum):
    CARD = "card"
    BLIK = "blik"
    APPLE_PAY = "apple_pay"
    GOOGLE_PAY = "google_pay"

class OrganizationCategory(str, Enum):
    RELIGIA = "religia"
    DZIECI = "dzieci"
    ZWIERZETA = "zwierzeta"
    EDUKACJA = "edukacja"
    ZDROWIE = "zdrowie"
    INNE = "inne"

# Organization Models
class OrganizationBase(BaseModel):
    name: str = Field(..., min_length=3, max_length=100)
    description: str = Field(..., min_length=10, max_length=1000)
    category: OrganizationCategory
    location: str = Field(..., min_length=2, max_length=50)
    target_amount: float = Field(..., gt=0)
    contact_email: EmailStr
    website: Optional[str] = None

class OrganizationCreate(OrganizationBase):
    pass

class OrganizationUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=3, max_length=100)
    description: Optional[str] = Field(None, min_length=10, max_length=1000)
    category: Optional[OrganizationCategory] = None
    location: Optional[str] = Field(None, min_length=2, max_length=50)
    target_amount: Optional[float] = Field(None, gt=0)
    contact_email: Optional[EmailStr] = None
    website: Optional[str] = None

class Organization(OrganizationBase):
    id: str
    collected_amount: float = 0.0
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

# Payment Models
class PaymentRequest(BaseModel):
    organization_id: str = Field(..., min_length=1)
    amount: float = Field(..., gt=0, le=100000)  # Max 100k PLN
    method: PaymentMethod
    donor_email: Optional[EmailStr] = None
    donor_name: Optional[str] = Field(None, max_length=100)

class PaymentResponse(BaseModel):
    payment_id: str
    status: PaymentStatus
    amount: float
    organization_id: str
    method: PaymentMethod
    created_at: datetime
    redirect_url: Optional[str] = None
    
class Payment(BaseModel):
    id: str
    organization_id: str
    amount: float
    status: PaymentStatus
    method: PaymentMethod
    donor_email: Optional[str] = None
    donor_name: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    autopay_transaction_id: Optional[str] = None
    
    class Config:
        from_attributes = True

# Stats Models
class OrganizationStats(BaseModel):
    total_amount: float
    payment_count: int
    avg_payment: float
    last_payment: Optional[datetime] = None

class GlobalStats(BaseModel):
    total_organizations: int
    active_organizations: int
    total_donations: float
    total_payments: int
    avg_donation: float
    payments_today: int
    top_organizations: list[dict]

# API Response Models
class APIResponse(BaseModel):
    success: bool
    message: str
    data: Optional[dict] = None

class PaginatedResponse(BaseModel):
    items: list
    total: int
    page: int
    size: int
    pages: int

# Mock Autopay Models
class AutopayPaymentRequest(BaseModel):
    amount: float
    currency: str = "PLN"
    description: str
    return_url: str
    notify_url: str
    customer_email: Optional[str] = None

class AutopayPaymentResponse(BaseModel):
    transaction_id: str
    status: str
    redirect_url: str
    amount: float
    currency: str

class AutopayNotification(BaseModel):
    transaction_id: str
    status: str
    amount: float
    currency: str
    signature: str


# Organization Registration Models
class OrganizationStatus(str, Enum):
    PENDING = "pending"           # Oczekuje na weryfikację
    VERIFICATION_SENT = "verification_sent"  # Wysłano instrukcje weryfikacji
    VERIFIED = "verified"         # Zweryfikowana
    REJECTED = "rejected"         # Odrzucona
    SUSPENDED = "suspended"       # Zawieszona

class OrganizationRegistration(BaseModel):
    # Podstawowe dane organizacji
    name: str = Field(..., min_length=3, max_length=100)
    description: str = Field(..., min_length=10, max_length=1000)
    category: OrganizationCategory
    location: str = Field(..., min_length=2, max_length=50)
    target_amount: float = Field(..., gt=0)
    
    # Dane kontaktowe
    contact_email: EmailStr
    contact_phone: str = Field(..., min_length=9, max_length=15)
    contact_person: str = Field(..., min_length=2, max_length=100)
    
    # Dane organizacji
    legal_name: str = Field(..., min_length=3, max_length=150)  # Pełna nazwa prawna
    tax_id: str = Field(..., min_length=10, max_length=15)      # NIP/REGON
    registration_number: Optional[str] = Field(None, max_length=50)  # KRS
    address: str = Field(..., min_length=10, max_length=200)
    
    # Dane bankowe (dla weryfikacji)
    bank_account: str = Field(..., min_length=26, max_length=34)  # IBAN
    bank_name: str = Field(..., min_length=2, max_length=100)
    
    # Opcjonalne
    website: Optional[str] = None
    social_media: Optional[str] = None
    
    # Zgody
    terms_accepted: bool = Field(..., description="Akceptacja regulaminu")
    data_processing_consent: bool = Field(..., description="Zgoda na przetwarzanie danych")

class OrganizationRegistrationResponse(BaseModel):
    registration_id: str
    status: OrganizationStatus
    message: str
    verification_instructions: Optional[dict] = None
    estimated_verification_time: str = "1-3 dni robocze"

class VerificationPayment(BaseModel):
    registration_id: str
    amount: float = 1.0  # Zawsze 1 zł
    bank_account: str
    reference_number: str
    payment_title: str
    autopay_account: str
    instructions: str

class OrganizationVerificationStatus(BaseModel):
    registration_id: str
    status: OrganizationStatus
    submitted_at: datetime
    verified_at: Optional[datetime] = None
    verification_payment: Optional[VerificationPayment] = None
    admin_notes: Optional[str] = None
    organization_id: Optional[str] = None  # Po zatwierdzeniu

class OrganizationDashboard(BaseModel):
    registration: OrganizationRegistrationResponse
    verification_status: OrganizationVerificationStatus
    organization: Optional[Organization] = None  # Po zatwierdzeniu
    payments_summary: Optional[dict] = None      # Po zatwierdzeniu

