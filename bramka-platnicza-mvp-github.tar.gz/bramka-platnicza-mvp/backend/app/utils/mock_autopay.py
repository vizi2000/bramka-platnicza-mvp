import asyncio
import random
import hashlib
import time
from datetime import datetime
from typing import Dict, Optional
from app.models import AutopayPaymentRequest, AutopayPaymentResponse, AutopayNotification

class MockAutopayClient:
    """
    Mock implementacja klienta Autopay dla celów demonstracyjnych.
    Symuluje prawdziwe API Autopay z realistycznymi opóźnieniami i odpowiedziami.
    """
    
    def __init__(self, success_rate: float = 0.9, delay_ms: int = 2000):
        self.success_rate = success_rate
        self.delay_ms = delay_ms
        self.base_url = "https://mock-autopay.example.com"
        
    async def create_payment(self, request: AutopayPaymentRequest) -> AutopayPaymentResponse:
        """
        Tworzy nową płatność w systemie Autopay (mock).
        """
        # Symulacja opóźnienia sieciowego
        await asyncio.sleep(self.delay_ms / 1000.0)
        
        # Generowanie unikalnego ID transakcji
        transaction_id = self._generate_transaction_id()
        
        # Symulacja różnych statusów odpowiedzi
        if random.random() < self.success_rate:
            status = "pending"
            redirect_url = f"{self.base_url}/payment/{transaction_id}"
        else:
            # Symulacja błędów
            error_types = ["insufficient_funds", "card_declined", "timeout", "invalid_data"]
            error = random.choice(error_types)
            raise AutopayException(f"Payment failed: {error}")
        
        return AutopayPaymentResponse(
            transaction_id=transaction_id,
            status=status,
            redirect_url=redirect_url,
            amount=request.amount,
            currency=request.currency
        )
    
    async def get_payment_status(self, transaction_id: str) -> Dict:
        """
        Pobiera status płatności z Autopay (mock).
        """
        # Symulacja opóźnienia
        await asyncio.sleep(0.5)
        
        # Symulacja różnych statusów płatności
        statuses = ["pending", "completed", "failed"]
        weights = [0.1, 0.85, 0.05]  # 85% szans na sukces
        
        status = random.choices(statuses, weights=weights)[0]
        
        return {
            "transaction_id": transaction_id,
            "status": status,
            "amount": random.randint(10, 1000),
            "currency": "PLN",
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat()
        }
    
    def verify_notification(self, notification: AutopayNotification, secret_key: str) -> bool:
        """
        Weryfikuje podpis notyfikacji webhook od Autopay (mock).
        """
        # Symulacja weryfikacji podpisu
        expected_signature = self._generate_signature(
            notification.transaction_id,
            notification.status,
            notification.amount,
            secret_key
        )
        
        return notification.signature == expected_signature
    
    def _generate_transaction_id(self) -> str:
        """Generuje unikalny ID transakcji."""
        timestamp = str(int(time.time()))
        random_part = str(random.randint(100000, 999999))
        return f"ap_tx_{timestamp}_{random_part}"
    
    def _generate_signature(self, transaction_id: str, status: str, amount: float, secret_key: str) -> str:
        """Generuje podpis dla weryfikacji webhook."""
        data = f"{transaction_id}{status}{amount}{secret_key}"
        return hashlib.sha256(data.encode()).hexdigest()

class AutopayException(Exception):
    """Wyjątek dla błędów Autopay."""
    pass

# Singleton instance
autopay_client = MockAutopayClient()

# Funkcje pomocnicze
async def initiate_autopay_payment(
    amount: float,
    description: str,
    return_url: str,
    notify_url: str,
    customer_email: Optional[str] = None
) -> AutopayPaymentResponse:
    """
    Inicjuje płatność w systemie Autopay.
    """
    request = AutopayPaymentRequest(
        amount=amount,
        currency="PLN",
        description=description,
        return_url=return_url,
        notify_url=notify_url,
        customer_email=customer_email
    )
    
    return await autopay_client.create_payment(request)

async def check_autopay_payment_status(transaction_id: str) -> Dict:
    """
    Sprawdza status płatności w Autopay.
    """
    return await autopay_client.get_payment_status(transaction_id)

def verify_autopay_webhook(notification_data: Dict, secret_key: str) -> bool:
    """
    Weryfikuje webhook od Autopay.
    """
    try:
        notification = AutopayNotification(**notification_data)
        return autopay_client.verify_notification(notification, secret_key)
    except Exception:
        return False

# Konfiguracja mock responses dla różnych scenariuszy
MOCK_SCENARIOS = {
    "success": {
        "success_rate": 1.0,
        "delay_ms": 1500
    },
    "realistic": {
        "success_rate": 0.9,
        "delay_ms": 2000
    },
    "slow": {
        "success_rate": 0.8,
        "delay_ms": 5000
    },
    "unreliable": {
        "success_rate": 0.5,
        "delay_ms": 3000
    }
}

def configure_mock_autopay(scenario: str = "realistic"):
    """
    Konfiguruje mock Autopay dla różnych scenariuszy testowych.
    """
    global autopay_client
    
    if scenario in MOCK_SCENARIOS:
        config = MOCK_SCENARIOS[scenario]
        autopay_client = MockAutopayClient(
            success_rate=config["success_rate"],
            delay_ms=config["delay_ms"]
        )
    else:
        raise ValueError(f"Unknown scenario: {scenario}")

# Przykładowe użycie:
# configure_mock_autopay("realistic")  # Dla realistycznych testów
# configure_mock_autopay("success")    # Dla testów zawsze kończących się sukcesem

