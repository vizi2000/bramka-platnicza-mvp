import json
import os
import asyncio
from typing import List, Dict, Optional, Any
from datetime import datetime
import aiofiles

class JSONStorage:
    """
    Prosty system przechowywania danych w plikach JSON.
    Zapewnia atomic writes i basic locking dla bezpieczeństwa danych.
    """
    
    def __init__(self, data_dir: str = "app/data"):
        self.data_dir = data_dir
        self._locks = {}
        
        # Upewnij się, że folder data istnieje
        os.makedirs(data_dir, exist_ok=True)
    
    def _get_file_path(self, filename: str) -> str:
        """Zwraca pełną ścieżkę do pliku."""
        if not filename.endswith('.json'):
            filename += '.json'
        return os.path.join(self.data_dir, filename)
    
    def _get_lock(self, filename: str) -> asyncio.Lock:
        """Zwraca lock dla konkretnego pliku."""
        if filename not in self._locks:
            self._locks[filename] = asyncio.Lock()
        return self._locks[filename]
    
    async def read_json(self, filename: str) -> List[Dict]:
        """
        Odczytuje dane z pliku JSON.
        """
        file_path = self._get_file_path(filename)
        
        if not os.path.exists(file_path):
            return []
        
        try:
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                content = await f.read()
                return json.loads(content) if content.strip() else []
        except (json.JSONDecodeError, FileNotFoundError):
            return []
    
    async def write_json(self, filename: str, data: List[Dict]) -> bool:
        """
        Zapisuje dane do pliku JSON z atomic write.
        """
        file_path = self._get_file_path(filename)
        temp_path = f"{file_path}.tmp"
        
        lock = self._get_lock(filename)
        
        async with lock:
            try:
                # Zapisz do pliku tymczasowego
                async with aiofiles.open(temp_path, 'w', encoding='utf-8') as f:
                    await f.write(json.dumps(data, indent=2, ensure_ascii=False, default=str))
                
                # Atomic move
                os.replace(temp_path, file_path)
                return True
                
            except Exception as e:
                # Usuń plik tymczasowy w przypadku błędu
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                raise e
    
    async def find_by_id(self, filename: str, item_id: str) -> Optional[Dict]:
        """
        Znajduje element po ID.
        """
        data = await self.read_json(filename)
        return next((item for item in data if item.get('id') == item_id), None)
    
    async def find_by_field(self, filename: str, field: str, value: Any) -> List[Dict]:
        """
        Znajduje elementy po wartości pola.
        """
        data = await self.read_json(filename)
        return [item for item in data if item.get(field) == value]
    
    async def add_item(self, filename: str, item: Dict) -> bool:
        """
        Dodaje nowy element do pliku.
        """
        data = await self.read_json(filename)
        
        # Sprawdź czy element o takim ID już istnieje
        if any(existing.get('id') == item.get('id') for existing in data):
            return False
        
        # Dodaj timestamp
        item['created_at'] = item.get('created_at', datetime.utcnow().isoformat())
        item['updated_at'] = datetime.utcnow().isoformat()
        
        data.append(item)
        return await self.write_json(filename, data)
    
    async def update_item(self, filename: str, item_id: str, updates: Dict) -> bool:
        """
        Aktualizuje istniejący element.
        """
        data = await self.read_json(filename)
        
        for i, item in enumerate(data):
            if item.get('id') == item_id:
                # Aktualizuj pola
                data[i].update(updates)
                data[i]['updated_at'] = datetime.utcnow().isoformat()
                
                return await self.write_json(filename, data)
        
        return False
    
    async def delete_item(self, filename: str, item_id: str) -> bool:
        """
        Usuwa element po ID.
        """
        data = await self.read_json(filename)
        original_length = len(data)
        
        data = [item for item in data if item.get('id') != item_id]
        
        if len(data) < original_length:
            return await self.write_json(filename, data)
        
        return False
    
    async def get_stats(self, filename: str) -> Dict:
        """
        Zwraca podstawowe statystyki dla pliku.
        """
        data = await self.read_json(filename)
        
        return {
            "total_items": len(data),
            "file_size": os.path.getsize(self._get_file_path(filename)) if os.path.exists(self._get_file_path(filename)) else 0,
            "last_modified": datetime.fromtimestamp(
                os.path.getmtime(self._get_file_path(filename))
            ).isoformat() if os.path.exists(self._get_file_path(filename)) else None
        }

# Singleton instance
storage = JSONStorage()

# Funkcje pomocnicze dla organizacji
async def get_organizations() -> List[Dict]:
    """Pobiera wszystkie organizacje."""
    return await storage.read_json("organizations")

async def get_organization_by_id(org_id: str) -> Optional[Dict]:
    """Pobiera organizację po ID."""
    return await storage.find_by_id("organizations", org_id)

async def create_organization(org_data: Dict) -> bool:
    """Tworzy nową organizację."""
    return await storage.add_item("organizations", org_data)

async def update_organization(org_id: str, updates: Dict) -> bool:
    """Aktualizuje organizację."""
    return await storage.update_item("organizations", org_id, updates)

async def update_organization_collected_amount(org_id: str, amount: float) -> bool:
    """Aktualizuje zebraną kwotę organizacji."""
    org = await get_organization_by_id(org_id)
    if org:
        new_amount = org.get('collected_amount', 0) + amount
        return await update_organization(org_id, {'collected_amount': new_amount})
    return False

# Funkcje pomocnicze dla płatności
async def get_payments() -> List[Dict]:
    """Pobiera wszystkie płatności."""
    return await storage.read_json("payments")

async def get_payment_by_id(payment_id: str) -> Optional[Dict]:
    """Pobiera płatność po ID."""
    return await storage.find_by_id("payments", payment_id)

async def get_payments_by_organization(org_id: str) -> List[Dict]:
    """Pobiera płatności dla organizacji."""
    return await storage.find_by_field("payments", "organization_id", org_id)

async def create_payment(payment_data: Dict) -> bool:
    """Tworzy nową płatność."""
    return await storage.add_item("payments", payment_data)

async def update_payment_status(payment_id: str, status: str, autopay_transaction_id: Optional[str] = None) -> bool:
    """Aktualizuje status płatności."""
    updates = {'status': status}
    if autopay_transaction_id:
        updates['autopay_transaction_id'] = autopay_transaction_id
    
    return await storage.update_item("payments", payment_id, updates)

# Funkcje statystyk
async def get_global_stats() -> Dict:
    """Pobiera globalne statystyki."""
    organizations = await get_organizations()
    payments = await get_payments()
    
    total_donations = sum(org.get('collected_amount', 0) for org in organizations)
    completed_payments = [p for p in payments if p.get('status') == 'completed']
    
    # Płatności dzisiaj
    today = datetime.utcnow().date()
    payments_today = [
        p for p in payments 
        if datetime.fromisoformat(p.get('created_at', '').replace('Z', '+00:00')).date() == today
    ]
    
    # Top organizacje
    org_stats = {}
    for payment in completed_payments:
        org_id = payment.get('organization_id')
        if org_id:
            org_stats[org_id] = org_stats.get(org_id, 0) + payment.get('amount', 0)
    
    top_organizations = [
        {
            'organization_id': org_id,
            'total_amount': amount,
            'organization_name': next(
                (org['name'] for org in organizations if org['id'] == org_id), 
                'Unknown'
            )
        }
        for org_id, amount in sorted(org_stats.items(), key=lambda x: x[1], reverse=True)[:5]
    ]
    
    return {
        'total_organizations': len(organizations),
        'active_organizations': len([org for org in organizations if org.get('collected_amount', 0) > 0]),
        'total_donations': total_donations,
        'total_payments': len(payments),
        'completed_payments': len(completed_payments),
        'avg_donation': total_donations / len(completed_payments) if completed_payments else 0,
        'payments_today': len(payments_today),
        'top_organizations': top_organizations
    }


async def delete_organization(org_id: str) -> bool:
    """Usuwa organizację."""
    return await storage.delete_item("organizations", org_id)


# Funkcje pomocnicze dla rejestracji organizacji
async def get_organization_registrations() -> List[Dict]:
    """Pobiera wszystkie rejestracje organizacji."""
    return await storage.read_json("organization_registrations")

async def get_organization_registration_by_id(registration_id: str) -> Optional[Dict]:
    """Pobiera rejestrację organizacji po ID."""
    return await storage.find_by_id("organization_registrations", registration_id)

async def create_organization_registration(registration_data: Dict) -> bool:
    """Tworzy nową rejestrację organizacji."""
    return await storage.add_item("organization_registrations", registration_data)

async def update_organization_registration_status(
    registration_id: str, 
    status: str, 
    admin_notes: Optional[str] = None,
    verified_at: Optional[str] = None
) -> bool:
    """Aktualizuje status rejestracji organizacji."""
    updates = {'status': status}
    if admin_notes:
        updates['admin_notes'] = admin_notes
    if verified_at:
        updates['verified_at'] = verified_at
    
    return await storage.update_item("organization_registrations", registration_id, updates)

# Funkcje pomocnicze dla weryfikacji płatności
async def get_verification_payments() -> List[Dict]:
    """Pobiera wszystkie płatności weryfikacyjne."""
    return await storage.read_json("verification_payments")

async def get_verification_payment_by_registration_id(registration_id: str) -> Optional[Dict]:
    """Pobiera płatność weryfikacyjną po ID rejestracji."""
    payments = await get_verification_payments()
    return next((payment for payment in payments if payment.get('registration_id') == registration_id), None)

async def create_verification_payment(payment_data: Dict) -> bool:
    """Tworzy nową płatność weryfikacyjną."""
    return await storage.add_item("verification_payments", payment_data)

