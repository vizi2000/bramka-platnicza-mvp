from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
import os
from datetime import datetime

# Import routes
from app.routes.organizations import router as organizations_router
from app.routes.payments import router as payments_router
from app.routes.registration import router as registration_router

# Tworzenie aplikacji FastAPI
app = FastAPI(
    title="Bramka Płatnicza API",
    description="API dla systemu płatności organizacji charytatywnych",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Konfiguracja CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
        "http://0.0.0.0:3000",
        "http://0.0.0.0:5173"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rejestracja routerów
app.include_router(organizations_router, prefix="/api", tags=["Organizations"])
app.include_router(payments_router, prefix="/api", tags=["Payments"])
app.include_router(registration_router, prefix="/api/org", tags=["Organization Registration"])

# Health check endpoint
@app.get("/health")
async def health_check():
    """
    Endpoint sprawdzający stan aplikacji.
    """
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0",
        "service": "bramka-platnicza-api"
    }

# Root endpoint
@app.get("/")
async def root():
    """
    Główny endpoint API.
    """
    return {
        "message": "Bramka Płatnicza API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health",
        "endpoints": {
            "organizations": "/api/organizations",
            "payments": "/api/payments",
            "stats": "/api/stats"
        }
    }

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """
    Globalny handler dla nieobsłużonych wyjątków.
    """
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal Server Error",
            "message": "Wystąpił nieoczekiwany błąd serwera",
            "timestamp": datetime.utcnow().isoformat()
        }
    )

# Startup event
@app.on_event("startup")
async def startup_event():
    """
    Wykonywane przy starcie aplikacji.
    """
    print("🚀 Bramka Płatnicza API uruchomiona!")
    print("📚 Dokumentacja dostępna na: http://localhost:8000/docs")
    print("🏥 Health check: http://localhost:8000/health")

# Shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    """
    Wykonywane przy zamykaniu aplikacji.
    """
    print("🛑 Bramka Płatnicza API zatrzymana")

if __name__ == "__main__":
    # Konfiguracja serwera
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    
    print(f"🌟 Uruchamianie serwera na {host}:{port}")
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=True,
        log_level="info"
    )

