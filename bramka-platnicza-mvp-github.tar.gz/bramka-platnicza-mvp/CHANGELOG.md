# 📋 Changelog

Wszystkie istotne zmiany w projekcie będą dokumentowane w tym pliku.

Format oparty na [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
projekt używa [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planowane
- Prawdziwa integracja z Autopay API
- Dashboard dla organizacji
- Email notifications
- Eksport danych do CSV/PDF
- Aplikacja mobilna (React Native)

## [1.0.0] - 2025-01-06

### Dodane
- **Kompletne MVP bramki płatniczej**
- **Frontend React** z responsywnym designem
- **Backend FastAPI** z JSON storage
- **System płatności** z mock integracją Autopay
- **Panel administracyjny** z pełnym zarządzaniem
- **Rejestracja organizacji** z weryfikacją przez przelew 1 zł
- **Generator kodów QR** do udostępniania zbiórek
- **Real-time analytics** i statystyki
- **Docker support** dla łatwego wdrożenia

#### Frontend Features
- Strona główna z listą organizacji
- Strony płatności z wyborem kwot i metod
- 5-krokowy formularz rejestracji organizacji
- Panel administracyjny z 5 zakładkami:
  - Przegląd (statystyki, ostatnie płatności)
  - Organizacje (CRUD operations)
  - Płatności (tabela z filtrowaniem)
  - Analityka (wykresy metod płatności)
  - Konfiguracja (ustawienia API Autopay)
- Responsywny design (mobile + desktop)
- Dark theme z gradientami
- Loading states i animacje
- Error handling i walidacja formularzy

#### Backend Features
- RESTful API z FastAPI
- Pydantic models dla walidacji danych
- JSON storage system z atomic operations
- Mock Autopay integration z realistycznymi opóźnieniami
- Background tasks dla monitoringu płatności
- CORS middleware dla frontend integration
- Comprehensive error handling
- API documentation z Swagger UI

#### API Endpoints
- `/api/organizations` - zarządzanie organizacjami
- `/api/payments` - obsługa płatności
- `/api/org/register` - rejestracja organizacji
- `/api/admin/config` - konfiguracja API Autopay
- `/api/stats` - globalne statystyki

#### Komponenty React
- `PaymentMethods` - wybór metod płatności
- `QRGenerator` - generator kodów QR
- `OrganizationModal` - modal zarządzania organizacjami
- `AdminDashboard` - kompletny panel administracyjny
- `OrganizationRegistration` - formularz rejestracji

#### Technologie
- **Frontend**: React 18, Vite, Tailwind CSS, React Router DOM
- **Backend**: FastAPI, Pydantic, Uvicorn, Python-JOSE
- **Storage**: JSON files z thread-safe operations
- **DevOps**: Docker, Docker Compose
- **Icons**: Lucide React
- **QR Codes**: QRCode.js

### Naprawione
- Problem z polami input w formularzu rejestracji (re-rendering)
- Pusta strona po submit formularza rejestracji
- Konfiguracja Tailwind CSS v4 z PostCSS
- Error handling w API calls
- Walidacja danych po stronie frontend i backend

### Zmienione
- Przejście z Tailwind CSS v4 na v3 dla stabilności
- Optymalizacja handleInputChange z useCallback
- Ulepszenie error handling w całej aplikacji
- Dodanie maskowania klucza API w panelu admin

### Bezpieczeństwo
- Input validation z Pydantic
- CORS configuration
- Secure password handling w panelu admin
- API key masking w responses
- Environment variables dla wrażliwych danych

## [0.1.0] - 2025-01-05

### Dodane
- Początkowa struktura projektu
- Podstawowa konfiguracja Docker
- Szkielet aplikacji React i FastAPI

---

## Konwencje wersjonowania

### Major (X.0.0)
- Zmiany łamiące kompatybilność wsteczną
- Przepisanie znaczących części aplikacji
- Zmiana architektury

### Minor (0.X.0)
- Nowe funkcjonalności zachowujące kompatybilność
- Nowe API endpoints
- Nowe komponenty UI

### Patch (0.0.X)
- Poprawki błędów
- Małe ulepszenia
- Aktualizacje dokumentacji
- Poprawki bezpieczeństwa

## Typy zmian

- **Dodane** - nowe funkcjonalności
- **Zmienione** - zmiany w istniejących funkcjonalnościach
- **Przestarzałe** - funkcjonalności które będą usunięte
- **Usunięte** - usunięte funkcjonalności
- **Naprawione** - poprawki błędów
- **Bezpieczeństwo** - poprawki bezpieczeństwa

