# 🤝 Contributing to Bramka Płatnicza MVP

Dziękujemy za zainteresowanie współtworzeniem projektu! Ten przewodnik pomoże Ci zacząć.

## 📋 Spis treści

- [Code of Conduct](#code-of-conduct)
- [Jak mogę pomóc?](#jak-mogę-pomóc)
- [Zgłaszanie błędów](#zgłaszanie-błędów)
- [Propozycje funkcjonalności](#propozycje-funkcjonalności)
- [Proces rozwoju](#proces-rozwoju)
- [Standardy kodowania](#standardy-kodowania)
- [Testowanie](#testowanie)
- [Pull Requests](#pull-requests)

## 📜 Code of Conduct

Projekt przestrzega [Contributor Covenant Code of Conduct](CODE_OF_CONDUCT.md). Uczestnicząc w projekcie, zobowiązujesz się przestrzegać tych zasad.

## 🛠 Jak mogę pomóc?

### 🐛 Zgłaszanie błędów
- Sprawdź czy błąd nie został już zgłoszony w [Issues](https://github.com/your-username/bramka-platnicza-mvp/issues)
- Użyj szablonu zgłoszenia błędu
- Dołącz szczegółowe informacje o środowisku

### ✨ Propozycje funkcjonalności
- Sprawdź roadmap w README.md
- Otwórz issue z tagiem "enhancement"
- Opisz szczegółowo proponowaną funkcjonalność

### 💻 Kod
- Poprawki błędów
- Nowe funkcjonalności
- Ulepszenia wydajności
- Refactoring
- Dokumentacja

### 📚 Dokumentacja
- Poprawki w README.md
- Dodawanie przykładów
- Tłumaczenia
- API documentation

## 🐛 Zgłaszanie błędów

### Przed zgłoszeniem
1. **Sprawdź istniejące issues** - może błąd został już zgłoszony
2. **Przetestuj na najnowszej wersji** - może błąd został już naprawiony
3. **Sprawdź dokumentację** - może to nie jest błąd, tylko nieprawidłowe użycie

### Szablon zgłoszenia błędu
```markdown
**Opis błędu**
Krótki i jasny opis problemu.

**Kroki do reprodukcji**
1. Przejdź do '...'
2. Kliknij na '...'
3. Przewiń do '...'
4. Zobacz błąd

**Oczekiwane zachowanie**
Jasny opis tego, co powinno się stać.

**Screenshots**
Jeśli dotyczy, dodaj screenshots.

**Środowisko:**
- OS: [np. Windows 10, macOS 12.0, Ubuntu 20.04]
- Browser: [np. Chrome 96, Firefox 95, Safari 15]
- Node.js: [np. 18.12.0]
- Python: [np. 3.11.0]

**Dodatkowy kontekst**
Wszelkie inne informacje o problemie.
```

## 💡 Propozycje funkcjonalności

### Szablon propozycji
```markdown
**Czy propozycja jest związana z problemem?**
Jasny opis problemu. Np. "Frustruje mnie, że [...]"

**Opisz rozwiązanie**
Jasny opis tego, co chciałbyś zobaczyć.

**Opisz alternatywy**
Jasny opis alternatywnych rozwiązań.

**Dodatkowy kontekst**
Screenshots, mockupy, linki do podobnych implementacji.
```

## 🔄 Proces rozwoju

### 1. Fork repozytorium
```bash
# Fork na GitHub, potem:
git clone https://github.com/your-username/bramka-platnicza-mvp.git
cd bramka-platnicza-mvp
git remote add upstream https://github.com/original-owner/bramka-platnicza-mvp.git
```

### 2. Stwórz branch
```bash
# Dla nowej funkcjonalności
git checkout -b feature/amazing-feature

# Dla poprawki błędu
git checkout -b bugfix/fix-payment-issue

# Dla dokumentacji
git checkout -b docs/update-readme
```

### 3. Ustaw środowisko deweloperskie
```bash
# Backend
cd backend
pip install -r requirements.txt
pip install -r requirements-dev.txt  # jeśli istnieje

# Frontend
cd frontend
npm install
```

### 4. Wprowadź zmiany
- Pisz czytelny kod
- Dodaj testy dla nowych funkcjonalności
- Aktualizuj dokumentację
- Przestrzegaj standardów kodowania

### 5. Testuj zmiany
```bash
# Backend tests
cd backend
python -m pytest

# Frontend tests
cd frontend
npm test

# E2E tests
npm run test:e2e
```

### 6. Commit i push
```bash
git add .
git commit -m "feat: add amazing new feature"
git push origin feature/amazing-feature
```

### 7. Otwórz Pull Request
- Użyj szablonu PR
- Opisz zmiany szczegółowo
- Linkuj powiązane issues
- Dodaj screenshots jeśli dotyczy

## 📝 Standardy kodowania

### Python (Backend)
```python
# Używaj type hints
def create_payment(amount: float, description: str) -> Dict[str, Any]:
    pass

# Docstrings dla funkcji
def process_payment(payment_data: Dict) -> Payment:
    """
    Przetwarza płatność i zwraca obiekt Payment.
    
    Args:
        payment_data: Słownik z danymi płatności
        
    Returns:
        Payment: Obiekt przetworzonej płatności
        
    Raises:
        PaymentError: Gdy płatność nie może być przetworzona
    """
    pass

# Używaj Pydantic models
class PaymentRequest(BaseModel):
    amount: float = Field(..., gt=0, description="Kwota płatności")
    method: str = Field(..., regex="^(card|blik|apple_pay|google_pay)$")
```

### JavaScript/React (Frontend)
```javascript
// Używaj funkcyjnych komponentów z hooks
const PaymentForm = ({ onSubmit }) => {
  const [amount, setAmount] = useState(0);
  
  // Używaj useCallback dla funkcji
  const handleSubmit = useCallback((e) => {
    e.preventDefault();
    onSubmit({ amount });
  }, [amount, onSubmit]);
  
  return (
    <form onSubmit={handleSubmit}>
      {/* JSX */}
    </form>
  );
};

// PropTypes dla walidacji
PaymentForm.propTypes = {
  onSubmit: PropTypes.func.isRequired
};

// Eksportuj jako default
export default PaymentForm;
```

### CSS/Tailwind
```css
/* Używaj utility classes */
<div className="flex items-center justify-between p-4 bg-gray-800 rounded-lg">

/* Custom components w @layer */
@layer components {
  .btn-primary {
    @apply px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors;
  }
}
```

### Konwencje nazewnictwa

#### Pliki
- **React komponenty**: PascalCase (PaymentForm.jsx)
- **Utilities**: camelCase (mockData.js)
- **API routes**: snake_case (organizations.py)
- **Stylesheets**: kebab-case (payment-form.css)

#### Zmienne i funkcje
- **JavaScript**: camelCase (handlePayment)
- **Python**: snake_case (process_payment)
- **Constants**: UPPER_SNAKE_CASE (API_BASE_URL)

#### Git commits
Używamy [Conventional Commits](https://www.conventionalcommits.org/):

```bash
# Typy commitów
feat: nowa funkcjonalność
fix: poprawka błędu
docs: dokumentacja
style: formatowanie, brakujące średniki
refactor: refactoring kodu
test: dodanie testów
chore: aktualizacja build tools, dependencies

# Przykłady
feat: add payment method selection
fix: resolve QR code generation issue
docs: update API documentation
style: format payment components
refactor: extract payment utilities
test: add payment form tests
chore: update dependencies
```

## 🧪 Testowanie

### Backend Tests
```python
# test_payments.py
import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_create_payment():
    payment_data = {
        "organization_id": "test-org",
        "amount": 100.0,
        "method": "card",
        "donor_email": "test@example.com"
    }
    response = client.post("/api/payments/initiate", json=payment_data)
    assert response.status_code == 200
    assert response.json()["amount"] == 100.0

@pytest.fixture
def sample_organization():
    return {
        "name": "Test Organization",
        "description": "Test description",
        "category": "test",
        "location": "Test City",
        "target_amount": 10000,
        "contact_email": "test@example.com",
        "contact_phone": "+48123456789",
        "contact_person": "Test Person"
    }
```

### Frontend Tests
```javascript
// PaymentForm.test.jsx
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import PaymentForm from '../PaymentForm';

test('renders payment form', () => {
  render(<PaymentForm onSubmit={jest.fn()} />);
  expect(screen.getByText('Kwota')).toBeInTheDocument();
});

test('submits form with correct data', async () => {
  const mockSubmit = jest.fn();
  render(<PaymentForm onSubmit={mockSubmit} />);
  
  fireEvent.change(screen.getByLabelText('Kwota'), {
    target: { value: '100' }
  });
  fireEvent.click(screen.getByText('Wpłać'));
  
  await waitFor(() => {
    expect(mockSubmit).toHaveBeenCalledWith({ amount: 100 });
  });
});
```

### Uruchamianie testów
```bash
# Backend
cd backend
python -m pytest -v
python -m pytest --cov=app tests/  # z coverage

# Frontend
cd frontend
npm test
npm run test:coverage

# E2E (jeśli skonfigurowane)
npm run test:e2e
```

## 🔄 Pull Requests

### Szablon PR
```markdown
## Opis
Krótki opis zmian wprowadzonych w PR.

## Typ zmiany
- [ ] Bug fix (non-breaking change)
- [ ] New feature (non-breaking change)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update

## Jak zostało przetestowane?
Opisz testy które przeprowadziłeś.

## Checklist:
- [ ] Kod przestrzega standardów projektu
- [ ] Przeprowadziłem self-review kodu
- [ ] Skomentowałem kod w trudnych do zrozumienia miejscach
- [ ] Zaktualizowałem dokumentację
- [ ] Dodałem testy pokrywające zmiany
- [ ] Wszystkie testy przechodzą lokalnie
- [ ] Zmiany nie wprowadzają nowych warnings

## Screenshots (jeśli dotyczy):
Dodaj screenshots pokazujące zmiany w UI.

## Powiązane issues:
Closes #123
```

### Proces review
1. **Automatyczne sprawdzenia** - CI/CD musi przejść
2. **Code review** - co najmniej jeden maintainer musi zaaprobować
3. **Testy** - wszystkie testy muszą przechodzić
4. **Dokumentacja** - sprawdzenie czy dokumentacja jest aktualna

### Po merge
- Branch zostanie automatycznie usunięty
- Zmiana zostanie dodana do CHANGELOG.md
- Release notes zostaną zaktualizowane

## 🏷 Labeling

### Issues
- `bug` - błędy do naprawienia
- `enhancement` - nowe funkcjonalności
- `documentation` - aktualizacje dokumentacji
- `good first issue` - dobre dla początkujących
- `help wanted` - potrzebna pomoc społeczności
- `priority: high` - wysokie priorytety
- `priority: low` - niskie priorytety

### Pull Requests
- `work in progress` - PR w trakcie pracy
- `ready for review` - gotowe do review
- `needs changes` - wymaga zmian
- `approved` - zaaprobowane

## 🎉 Uznanie

Wszyscy kontrybutorzy będą dodani do sekcji Contributors w README.md.

## 📞 Kontakt

Jeśli masz pytania:
- Otwórz issue z tagiem "question"
- Napisz email: contributors@bramka-platnicza.pl
- Dołącz do naszego Discord: [link]

Dziękujemy za wkład w rozwój projektu! 🚀

