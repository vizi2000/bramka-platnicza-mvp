import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Building2, 
  Mail, 
  Phone, 
  MapPin, 
  CreditCard, 
  FileText, 
  User, 
  Globe,
  AlertCircle,
  CheckCircle,
  Clock,
  ArrowRight,
  ArrowLeft,
  Shield
} from 'lucide-react';
import axios from 'axios';

const API_BASE = 'http://localhost:8000/api/org';

const OrganizationRegistration = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const [formData, setFormData] = useState({
    // Podstawowe dane organizacji
    name: '',
    description: '',
    category: 'inne',
    location: '',
    target_amount: '',
    
    // Dane kontaktowe
    contact_email: '',
    contact_phone: '',
    contact_person: '',
    
    // Dane prawne organizacji
    legal_name: '',
    tax_id: '',
    registration_number: '',
    address: '',
    
    // Dane bankowe
    bank_account: '',
    bank_name: '',
    
    // Opcjonalne
    website: '',
    
    // Zgody
    terms_accepted: false,
    data_processing_consent: false
  });

  const categories = [
    { value: 'religia', label: 'Religia i duchowość' },
    { value: 'dzieci', label: 'Dzieci i młodzież' },
    { value: 'zwierzeta', label: 'Ochrona zwierząt' },
    { value: 'edukacja', label: 'Edukacja' },
    { value: 'zdrowie', label: 'Zdrowie' },
    { value: 'srodowisko', label: 'Ochrona środowiska' },
    { value: 'kultura', label: 'Kultura i sztuka' },
    { value: 'sport', label: 'Sport i rekreacja' },
    { value: 'inne', label: 'Inne' }
  ];

  const steps = [
    { id: 1, title: 'Podstawowe dane', icon: Building2 },
    { id: 2, title: 'Dane kontaktowe', icon: User },
    { id: 3, title: 'Dane prawne', icon: FileText },
    { id: 4, title: 'Dane bankowe', icon: CreditCard },
    { id: 5, title: 'Podsumowanie', icon: CheckCircle }
  ];

  // Używamy useCallback aby zapobiec re-renderom
  const handleInputChange = useCallback((field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error for this field
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: null
      }));
    }
  }, [errors]);

  const validateStep = (step) => {
    const newErrors = {};

    switch (step) {
      case 1:
        if (!formData.name.trim()) newErrors.name = 'Nazwa organizacji jest wymagana';
        if (!formData.description.trim()) newErrors.description = 'Opis organizacji jest wymagany';
        if (!formData.location.trim()) newErrors.location = 'Lokalizacja jest wymagana';
        if (!formData.target_amount || formData.target_amount <= 0) {
          newErrors.target_amount = 'Cel zbiórki musi być większy od 0';
        }
        break;

      case 2:
        if (!formData.contact_email.trim()) newErrors.contact_email = 'Email jest wymagany';
        if (!formData.contact_email.includes('@')) newErrors.contact_email = 'Nieprawidłowy format email';
        if (!formData.contact_phone.trim()) newErrors.contact_phone = 'Telefon jest wymagany';
        if (!formData.contact_person.trim()) newErrors.contact_person = 'Osoba kontaktowa jest wymagana';
        break;

      case 3:
        if (!formData.legal_name.trim()) newErrors.legal_name = 'Nazwa prawna jest wymagana';
        if (!formData.tax_id.trim()) newErrors.tax_id = 'NIP jest wymagany';
        if (!formData.registration_number.trim()) newErrors.registration_number = 'Numer rejestrowy jest wymagany';
        if (!formData.address.trim()) newErrors.address = 'Adres jest wymagany';
        break;

      case 4:
        if (!formData.bank_account.trim()) newErrors.bank_account = 'Numer konta jest wymagany';
        if (!formData.bank_name.trim()) newErrors.bank_name = 'Nazwa banku jest wymagana';
        break;

      case 5:
        if (!formData.terms_accepted) newErrors.terms_accepted = 'Musisz zaakceptować regulamin';
        if (!formData.data_processing_consent) newErrors.data_processing_consent = 'Musisz wyrazić zgodę na przetwarzanie danych';
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, 5));
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = async () => {
    if (!validateStep(5)) return;

    setLoading(true);
    try {
      const response = await axios.post(`${API_BASE}/register`, {
        ...formData,
        target_amount: parseFloat(formData.target_amount)
      });

      if (response.data && response.data.registration_id) {
        // Redirect to status page
        navigate(`/org/status/${response.data.registration_id}`);
      } else {
        throw new Error('Brak ID rejestracji w odpowiedzi');
      }
    } catch (error) {
      console.error('Registration error:', error);
      setErrors({
        submit: error.response?.data?.detail || 'Wystąpił błąd podczas rejestracji'
      });
    } finally {
      setLoading(false);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-white mb-4">Podstawowe dane organizacji</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Nazwa organizacji *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.name ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="np. Fundacja Pomocy Dzieciom"
              />
              {errors.name && <p className="text-red-400 text-sm mt-1">{errors.name}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Opis organizacji *
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={4}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.description ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="Opisz misję i cele Twojej organizacji..."
              />
              {errors.description && <p className="text-red-400 text-sm mt-1">{errors.description}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Kategoria *
              </label>
              <select
                value={formData.category}
                onChange={(e) => handleInputChange('category', e.target.value)}
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {categories.map(cat => (
                  <option key={cat.value} value={cat.value}>{cat.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Lokalizacja *
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => handleInputChange('location', e.target.value)}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.location ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="np. Warszawa, Kraków, cała Polska"
              />
              {errors.location && <p className="text-red-400 text-sm mt-1">{errors.location}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Cel zbiórki (PLN) *
              </label>
              <input
                type="number"
                value={formData.target_amount}
                onChange={(e) => handleInputChange('target_amount', e.target.value)}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.target_amount ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="50000"
                min="1"
              />
              {errors.target_amount && <p className="text-red-400 text-sm mt-1">{errors.target_amount}</p>}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-white mb-4">Dane kontaktowe</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Email kontaktowy *
              </label>
              <input
                type="email"
                value={formData.contact_email}
                onChange={(e) => handleInputChange('contact_email', e.target.value)}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.contact_email ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="kontakt@organizacja.pl"
              />
              {errors.contact_email && <p className="text-red-400 text-sm mt-1">{errors.contact_email}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Telefon kontaktowy *
              </label>
              <input
                type="tel"
                value={formData.contact_phone}
                onChange={(e) => handleInputChange('contact_phone', e.target.value)}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.contact_phone ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="+48 123 456 789"
              />
              {errors.contact_phone && <p className="text-red-400 text-sm mt-1">{errors.contact_phone}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Osoba kontaktowa *
              </label>
              <input
                type="text"
                value={formData.contact_person}
                onChange={(e) => handleInputChange('contact_person', e.target.value)}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.contact_person ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="Jan Kowalski"
              />
              {errors.contact_person && <p className="text-red-400 text-sm mt-1">{errors.contact_person}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Strona internetowa
              </label>
              <input
                type="url"
                value={formData.website}
                onChange={(e) => handleInputChange('website', e.target.value)}
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="https://organizacja.pl"
              />
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-white mb-4">Dane prawne organizacji</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Pełna nazwa prawna *
              </label>
              <input
                type="text"
                value={formData.legal_name}
                onChange={(e) => handleInputChange('legal_name', e.target.value)}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.legal_name ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="Fundacja Pomocy Dzieciom"
              />
              {errors.legal_name && <p className="text-red-400 text-sm mt-1">{errors.legal_name}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                NIP *
              </label>
              <input
                type="text"
                value={formData.tax_id}
                onChange={(e) => handleInputChange('tax_id', e.target.value)}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.tax_id ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="1234567890"
              />
              {errors.tax_id && <p className="text-red-400 text-sm mt-1">{errors.tax_id}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Numer rejestrowy (KRS/REGON) *
              </label>
              <input
                type="text"
                value={formData.registration_number}
                onChange={(e) => handleInputChange('registration_number', e.target.value)}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.registration_number ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="KRS0000123456"
              />
              {errors.registration_number && <p className="text-red-400 text-sm mt-1">{errors.registration_number}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Adres siedziby *
              </label>
              <textarea
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                rows={3}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.address ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="ul. Przykładowa 123, 00-000 Warszawa"
              />
              {errors.address && <p className="text-red-400 text-sm mt-1">{errors.address}</p>}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-white mb-4">Dane bankowe</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Numer konta bankowego *
              </label>
              <input
                type="text"
                value={formData.bank_account}
                onChange={(e) => handleInputChange('bank_account', e.target.value)}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.bank_account ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="PL12345678901234567890123456"
              />
              {errors.bank_account && <p className="text-red-400 text-sm mt-1">{errors.bank_account}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Nazwa banku *
              </label>
              <input
                type="text"
                value={formData.bank_name}
                onChange={(e) => handleInputChange('bank_name', e.target.value)}
                className={`w-full px-4 py-3 bg-gray-700 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  errors.bank_name ? 'border-red-500' : 'border-gray-600'
                }`}
                placeholder="Bank PKO BP S.A."
              />
              {errors.bank_name && <p className="text-red-400 text-sm mt-1">{errors.bank_name}</p>}
            </div>

            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
              <h4 className="text-blue-400 font-medium mb-2">Ważne informacje:</h4>
              <ul className="text-sm text-blue-300 space-y-1">
                <li>• Konto bankowe musi być zarejestrowane na organizację</li>
                <li>• Z tego konta zostanie wykonany przelew weryfikacyjny 1 zł</li>
                <li>• Na to konto będą wpływać donacje od darczyńców</li>
              </ul>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-white mb-4">Podsumowanie i zgody</h3>
            
            {/* Summary */}
            <div className="bg-gray-800 rounded-lg p-6 space-y-4">
              <h4 className="font-medium text-white">Podsumowanie danych:</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-400">Nazwa:</span>
                  <span className="text-white ml-2">{formData.name}</span>
                </div>
                <div>
                  <span className="text-gray-400">Kategoria:</span>
                  <span className="text-white ml-2">
                    {categories.find(c => c.value === formData.category)?.label}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400">Email:</span>
                  <span className="text-white ml-2">{formData.contact_email}</span>
                </div>
                <div>
                  <span className="text-gray-400">Cel zbiórki:</span>
                  <span className="text-white ml-2">{formData.target_amount} PLN</span>
                </div>
              </div>
            </div>

            {/* Consents */}
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  id="terms"
                  checked={formData.terms_accepted}
                  onChange={(e) => handleInputChange('terms_accepted', e.target.checked)}
                  className="mt-1 w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500"
                />
                <label htmlFor="terms" className="text-sm text-gray-300">
                  Akceptuję <a href="#" className="text-blue-400 hover:underline">regulamin serwisu</a> i 
                  <a href="#" className="text-blue-400 hover:underline ml-1">warunki korzystania</a> *
                </label>
              </div>
              {errors.terms_accepted && <p className="text-red-400 text-sm">{errors.terms_accepted}</p>}

              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  id="privacy"
                  checked={formData.data_processing_consent}
                  onChange={(e) => handleInputChange('data_processing_consent', e.target.checked)}
                  className="mt-1 w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500"
                />
                <label htmlFor="privacy" className="text-sm text-gray-300">
                  Wyrażam zgodę na przetwarzanie moich danych osobowych zgodnie z 
                  <a href="#" className="text-blue-400 hover:underline ml-1">polityką prywatności</a> *
                </label>
              </div>
              {errors.data_processing_consent && <p className="text-red-400 text-sm">{errors.data_processing_consent}</p>}
            </div>

            {errors.submit && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
                <p className="text-red-400">{errors.submit}</p>
              </div>
            )}

            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
              <h4 className="text-yellow-400 font-medium mb-2">Następne kroki:</h4>
              <ol className="text-sm text-yellow-300 space-y-1">
                <li>1. Po rejestracji otrzymasz instrukcje weryfikacji</li>
                <li>2. Wykonaj przelew weryfikacyjny 1 zł z konta organizacji</li>
                <li>3. Poczekaj na weryfikację (1-3 dni robocze)</li>
                <li>4. Po weryfikacji Twoja organizacja będzie aktywna</li>
              </ol>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">
            Rejestracja organizacji
          </h1>
          <p className="text-gray-400">
            Dołącz do platformy i zacznij zbierać donacje dla swojej organizacji
          </p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => {
              const StepIcon = step.icon;
              const isActive = currentStep === step.id;
              const isCompleted = currentStep > step.id;
              
              return (
                <div key={step.id} className="flex items-center">
                  <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                    isCompleted 
                      ? 'bg-green-500 border-green-500 text-white' 
                      : isActive 
                        ? 'bg-blue-500 border-blue-500 text-white' 
                        : 'bg-gray-700 border-gray-600 text-gray-400'
                  }`}>
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5" />
                    ) : (
                      <StepIcon className="w-5 h-5" />
                    )}
                  </div>
                  <div className="ml-3 hidden sm:block">
                    <p className={`text-sm font-medium ${
                      isActive ? 'text-white' : 'text-gray-400'
                    }`}>
                      {step.title}
                    </p>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`hidden sm:block w-16 h-0.5 ml-4 ${
                      isCompleted ? 'bg-green-500' : 'bg-gray-600'
                    }`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Form Content */}
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-8">
          {renderStepContent()}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 pt-6 border-t border-gray-700">
            <button
              onClick={prevStep}
              disabled={currentStep === 1}
              className="flex items-center space-x-2 px-6 py-3 bg-gray-700 hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Wstecz</span>
            </button>

            {currentStep < 5 ? (
              <button
                onClick={nextStep}
                className="flex items-center space-x-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                <span>Dalej</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={loading}
                className="flex items-center space-x-2 px-6 py-3 bg-green-600 hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>Rejestrowanie...</span>
                  </>
                ) : (
                  <>
                    <Shield className="w-4 h-4" />
                    <span>Zarejestruj organizację</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Back to Home */}
        <div className="text-center mt-8">
          <button
            onClick={() => navigate('/')}
            className="text-gray-400 hover:text-white transition-colors"
          >
            ← Powrót do strony głównej
          </button>
        </div>
      </div>
    </div>
  );
};

export default OrganizationRegistration;

