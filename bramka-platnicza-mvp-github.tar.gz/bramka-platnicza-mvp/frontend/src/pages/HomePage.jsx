import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Users, Target, ArrowRight } from 'lucide-react';
import { mockOrganizations, formatCurrency, getTotalDonations, getTotalPayments } from '../utils/mockData';

const HomePage = () => {
  const totalDonations = getTotalDonations();
  const totalPayments = getTotalPayments();

  const getProgressPercentage = (collected, target) => {
    return Math.min((collected / target) * 100, 100);
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'religia':
        return '⛪';
      case 'dzieci':
        return '👶';
      case 'zwierzeta':
        return '🐕';
      default:
        return '❤️';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <div className="bg-gray-800/50 backdrop-blur-sm border-b border-gray-700">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-primary-500 to-primary-600 rounded-xl flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-white">Bramka Płatnicza</h1>
            </div>
            <p className="text-xl text-gray-300 mb-6">
              Wspieraj lokalne organizacje charytatywne
            </p>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Bezpieczne i szybkie płatności dla organizacji non-profit. 
              Każda złotówka trafia bezpośrednio do potrzebujących.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="card text-center">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Target className="w-6 h-6 text-green-400" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-1">
              {formatCurrency(totalDonations)}
            </h3>
            <p className="text-gray-400">Zebrano łącznie</p>
          </div>
          
          <div className="card text-center">
            <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Users className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-1">
              {mockOrganizations.length}
            </h3>
            <p className="text-gray-400">Aktywne organizacje</p>
          </div>
          
          <div className="card text-center">
            <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Heart className="w-6 h-6 text-purple-400" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-1">
              {totalPayments}
            </h3>
            <p className="text-gray-400">Dokonanych wpłat</p>
          </div>
        </div>

        {/* Organizations List */}
        <div className="space-y-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-white mb-2">
              Wybierz organizację do wsparcia
            </h2>
            <p className="text-gray-400">
              Kliknij na organizację, aby przejść do strony wpłat
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {mockOrganizations.map((org) => {
              const progressPercentage = getProgressPercentage(org.collected_amount, org.target_amount);
              
              return (
                <Link
                  key={org.id}
                  to={`/donate/${org.id}`}
                  className="card hover:bg-gray-700/50 transition-all duration-200 hover:scale-105 group"
                >
                  <div className="flex items-start space-x-4">
                    {/* Organization Icon */}
                    <div className="w-16 h-16 bg-gradient-to-br from-primary-500 to-primary-600 rounded-xl flex items-center justify-center flex-shrink-0 text-2xl">
                      {getCategoryIcon(org.category)}
                    </div>
                    
                    {/* Organization Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="text-lg font-semibold text-white group-hover:text-primary-400 transition-colors">
                          {org.name}
                        </h3>
                        <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-primary-400 transition-colors flex-shrink-0 ml-2" />
                      </div>
                      
                      <p className="text-gray-300 text-sm mb-4 line-clamp-2">
                        {org.description}
                      </p>
                      
                      {/* Location */}
                      <p className="text-xs text-gray-400 mb-3">
                        📍 {org.location}
                      </p>
                      
                      {/* Progress */}
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Zebrano</span>
                          <span className="text-gray-400">Cel</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div 
                            className="bg-gradient-to-r from-primary-500 to-primary-400 h-2 rounded-full transition-all duration-1000 ease-out"
                            style={{ width: `${progressPercentage}%` }}
                          ></div>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm font-semibold text-white">
                            {formatCurrency(org.collected_amount)}
                          </span>
                          <span className="text-sm text-gray-400">
                            {formatCurrency(org.target_amount)}
                          </span>
                        </div>
                        <p className="text-xs text-gray-400">
                          {progressPercentage.toFixed(1)}% celu osiągnięte
                        </p>
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Call to Action */}
        <div className="mt-12 text-center">
          <div className="card bg-gradient-to-r from-primary-500/20 to-purple-500/20 border-primary-500/30">
            <h3 className="text-xl font-bold text-white mb-2">
              Każda pomoc się liczy
            </h3>
            <p className="text-gray-300 mb-4">
              Dołącz do tysięcy osób, które już wsparły lokalne organizacje charytatywne
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/donate/parafia-sw-jana"
                className="btn-primary"
              >
                Wpłać darowiznę
              </Link>
              <Link
                to="/org/register"
                className="btn-secondary"
              >
                Zarejestruj organizację
              </Link>
              <Link
                to="/admin"
                className="btn-secondary"
              >
                Panel administratora
              </Link>
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mx-auto mb-3">
              <span className="text-2xl">🔒</span>
            </div>
            <h4 className="font-semibold text-white mb-2">Bezpieczne płatności</h4>
            <p className="text-sm text-gray-400">
              Wszystkie transakcje są szyfrowane i chronione przez Autopay
            </p>
          </div>
          
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mx-auto mb-3">
              <span className="text-2xl">⚡</span>
            </div>
            <h4 className="font-semibold text-white mb-2">Szybkie wpłaty</h4>
            <p className="text-sm text-gray-400">
              Wpłać w kilka sekund kartą, BLIK-iem lub płatnościami mobilnymi
            </p>
          </div>
          
          <div className="text-center">
            <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mx-auto mb-3">
              <span className="text-2xl">📱</span>
            </div>
            <h4 className="font-semibold text-white mb-2">Mobilne QR kody</h4>
            <p className="text-sm text-gray-400">
              Skanuj kod QR telefonem i wpłacaj bez wpisywania adresów
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;

