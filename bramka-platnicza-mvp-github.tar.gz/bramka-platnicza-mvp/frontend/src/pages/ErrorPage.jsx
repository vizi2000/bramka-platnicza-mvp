import React from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, Home, ArrowLeft } from 'lucide-react';

const ErrorPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-gray-800 to-gray-900 flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center">
        {/* Error Icon */}
        <div className="mb-8">
          <div className="w-24 h-24 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="w-12 h-12 text-red-400" />
          </div>
        </div>

        {/* Error Message */}
        <div className="card space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">
              Ups! Coś poszło nie tak
            </h1>
            <p className="text-gray-300">
              Nie mogliśmy znaleźć strony, której szukasz
            </p>
          </div>

          {/* Error Details */}
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
            <h3 className="font-semibold text-red-400 mb-2">Możliwe przyczyny:</h3>
            <ul className="text-sm text-gray-300 space-y-1 text-left">
              <li>• Organizacja o podanym ID nie istnieje</li>
              <li>• Link został nieprawidłowo skopiowany</li>
              <li>• Strona została przeniesiona lub usunięta</li>
              <li>• Wystąpił tymczasowy problem techniczny</li>
            </ul>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <Link
              to="/"
              className="w-full btn-primary flex items-center justify-center space-x-2"
            >
              <Home className="w-5 h-5" />
              <span>Powrót do strony głównej</span>
            </Link>
            
            <button
              onClick={() => window.history.back()}
              className="w-full btn-secondary flex items-center justify-center space-x-2"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Wróć do poprzedniej strony</span>
            </button>
          </div>

          {/* Help Section */}
          <div className="text-sm text-gray-400 space-y-2">
            <p>
              Jeśli problem się powtarza, skontaktuj się z nami:
            </p>
            <p>
              📧 <a href="mailto:pomoc@bramka-platnicza.pl" className="text-primary-400 hover:text-primary-300">
                pomoc@bramka-platnicza.pl
              </a>
            </p>
          </div>
        </div>

        {/* Available Organizations */}
        <div className="mt-8">
          <p className="text-gray-400 text-sm mb-4">
            Lub wybierz jedną z dostępnych organizacji:
          </p>
          <div className="space-y-2">
            <Link
              to="/donate/parafia-sw-jana"
              className="block text-primary-400 hover:text-primary-300 text-sm transition-colors"
            >
              → Parafia św. Jana
            </Link>
            <Link
              to="/donate/fundacja-pomocy-dzieciom"
              className="block text-primary-400 hover:text-primary-300 text-sm transition-colors"
            >
              → Fundacja Pomocy Dzieciom
            </Link>
            <Link
              to="/donate/schronisko-azyl"
              className="block text-primary-400 hover:text-primary-300 text-sm transition-colors"
            >
              → Schronisko "Azyl"
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ErrorPage;

