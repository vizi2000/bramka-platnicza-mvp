import React, { useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { CheckCircle, Heart, Share2, Home } from 'lucide-react';

const SuccessPage = () => {
  const [searchParams] = useSearchParams();
  const amount = searchParams.get('amount');
  const orgName = searchParams.get('org');
  const method = searchParams.get('method');

  useEffect(() => {
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
  }, []);

  const getMethodName = (method) => {
    const methods = {
      'card': 'Karta płatnicza',
      'blik': 'BLIK',
      'apple_pay': 'Apple Pay',
      'google_pay': 'Google Pay'
    };
    return methods[method] || method;
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `Wsparłem ${orgName}`,
        text: `Właśnie wsparłem ${orgName} kwotą ${amount} PLN. Dołącz do mnie!`,
        url: window.location.origin
      });
    } else {
      // Fallback - copy to clipboard
      const text = `Właśnie wsparłem ${orgName} kwotą ${amount} PLN. Dołącz do mnie! ${window.location.origin}`;
      navigator.clipboard.writeText(text);
      alert('Link skopiowany do schowka!');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-gray-800 to-gray-900 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        {/* Success Animation */}
        <div className="text-center mb-8">
          <div className="relative">
            <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse-slow">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
            {/* Animated rings */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-32 h-32 border-2 border-green-400 rounded-full animate-ping opacity-20"></div>
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-40 h-40 border-2 border-green-300 rounded-full animate-ping opacity-10" style={{ animationDelay: '0.5s' }}></div>
            </div>
          </div>
        </div>

        {/* Success Message */}
        <div className="card text-center space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">
              Dziękujemy za wsparcie! 🎉
            </h1>
            <p className="text-gray-300">
              Twoja płatność została pomyślnie przetworzona
            </p>
          </div>

          {/* Payment Details */}
          <div className="bg-gray-700/50 rounded-lg p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Kwota:</span>
              <span className="text-xl font-bold text-green-400">{amount} PLN</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Organizacja:</span>
              <span className="text-white font-medium">{orgName}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Metoda płatności:</span>
              <span className="text-white">{getMethodName(method)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Status:</span>
              <span className="text-green-400 font-medium">✓ Zakończona</span>
            </div>
          </div>

          {/* Thank You Message */}
          <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-lg p-4 border border-green-500/30">
            <div className="flex items-center space-x-3">
              <Heart className="w-6 h-6 text-red-400 flex-shrink-0" />
              <div className="text-left">
                <h3 className="font-semibold text-white">Twoje wsparcie ma znaczenie</h3>
                <p className="text-sm text-gray-300 mt-1">
                  Dzięki Tobie {orgName} może kontynuować swoją misję pomagania innym.
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <button
              onClick={handleShare}
              className="w-full btn-primary flex items-center justify-center space-x-2"
            >
              <Share2 className="w-5 h-5" />
              <span>Podziel się swoim wsparciem</span>
            </button>
            
            <Link
              to="/"
              className="w-full btn-secondary flex items-center justify-center space-x-2"
            >
              <Home className="w-5 h-5" />
              <span>Powrót do strony głównej</span>
            </Link>
          </div>

          {/* Additional Info */}
          <div className="text-sm text-gray-400 space-y-2">
            <p>
              📧 Potwierdzenie płatności zostanie wysłane na Twój adres email
            </p>
            <p>
              🧾 Możesz użyć tej płatności do odliczenia podatkowego
            </p>
          </div>
        </div>

        {/* Encourage More Donations */}
        <div className="mt-8 text-center">
          <p className="text-gray-400 text-sm mb-4">
            Znasz inne organizacje, które potrzebują wsparcia?
          </p>
          <Link
            to="/"
            className="text-primary-400 hover:text-primary-300 font-medium transition-colors"
          >
            Sprawdź inne zbiórki →
          </Link>
        </div>
      </div>
    </div>
  );
};

export default SuccessPage;

