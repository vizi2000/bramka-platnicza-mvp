import React, { useState, useEffect } from 'react';
import { 
  Users, 
  CreditCard, 
  TrendingUp, 
  DollarSign, 
  Eye,
  Edit,
  Trash2,
  Plus,
  Search,
  Filter,
  Download,
  RefreshCw,
  Calendar,
  BarChart3,
  PieChart,
  Activity,
  LogOut,
  Settings,
  Key,
  Shield,
  Save,
  TestTube,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import axios from 'axios';
import OrganizationModal from '../components/OrganizationModal';

const API_BASE = 'http://localhost:8000/api';

const AdminDashboard = ({ onLogout }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [organizations, setOrganizations] = useState([]);
  const [payments, setPayments] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  
  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingOrganization, setEditingOrganization] = useState(null);

  // API Configuration states
  const [apiConfig, setApiConfig] = useState({
    autopay_api_key: '',
    autopay_environment: 'sandbox',
    autopay_merchant_id: '',
    webhook_url: '',
    verification_amount: 1.0,
    is_live_mode: false
  });
  const [configLoading, setConfigLoading] = useState(false);
  const [configSaved, setConfigSaved] = useState(false);

  // Fetch data
  useEffect(() => {
    fetchData();
    fetchApiConfig();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [orgsRes, paymentsRes, statsRes] = await Promise.all([
        axios.get(`${API_BASE}/organizations`),
        axios.get(`${API_BASE}/payments`),
        axios.get(`${API_BASE}/stats`)
      ]);
      
      setOrganizations(orgsRes.data);
      setPayments(paymentsRes.data);
      setStats(statsRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchApiConfig = async () => {
    try {
      const response = await axios.get(`${API_BASE}/admin/config`);
      setApiConfig(response.data);
    } catch (error) {
      console.error('Error fetching API config:', error);
      // Set default values if config doesn't exist
      setApiConfig({
        autopay_api_key: '',
        autopay_environment: 'sandbox',
        autopay_merchant_id: '',
        webhook_url: 'https://your-domain.com/api/payments/webhook',
        verification_amount: 1.0,
        is_live_mode: false
      });
    }
  };

  const saveApiConfig = async () => {
    setConfigLoading(true);
    try {
      await axios.put(`${API_BASE}/admin/config`, apiConfig);
      setConfigSaved(true);
      setTimeout(() => setConfigSaved(false), 3000);
    } catch (error) {
      console.error('Error saving API config:', error);
      alert('Błąd podczas zapisywania konfiguracji');
    } finally {
      setConfigLoading(false);
    }
  };

  const testApiConnection = async () => {
    try {
      const response = await axios.post(`${API_BASE}/admin/test-autopay`);
      alert(`Test połączenia: ${response.data.status === 'success' ? 'Sukces' : 'Błąd'}\\n${response.data.message}`);
    } catch (error) {
      alert('Błąd podczas testowania połączenia z Autopay');
    }
  };

  // Organization management
  const handleAddOrganization = () => {
    setEditingOrganization(null);
    setIsModalOpen(true);
  };

  const handleEditOrganization = (org) => {
    setEditingOrganization(org);
    setIsModalOpen(true);
  };

  const handleDeleteOrganization = async (orgId) => {
    if (window.confirm('Czy na pewno chcesz usunąć tę organizację?')) {
      try {
        await axios.delete(`${API_BASE}/organizations/${orgId}`);
        fetchData();
      } catch (error) {
        console.error('Error deleting organization:', error);
        alert('Błąd podczas usuwania organizacji');
      }
    }
  };

  const handleModalSave = async (orgData) => {
    try {
      if (editingOrganization) {
        await axios.put(`${API_BASE}/organizations/${editingOrganization.id}`, orgData);
      } else {
        await axios.post(`${API_BASE}/organizations`, orgData);
      }
      setIsModalOpen(false);
      fetchData();
    } catch (error) {
      console.error('Error saving organization:', error);
      throw error;
    }
  };

  // Filter and search
  const filteredOrganizations = organizations.filter(org => {
    const matchesSearch = org.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         org.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || org.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const filteredPayments = payments.filter(payment => 
    payment.organization_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    payment.donor_email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const tabs = [
    { id: 'overview', label: 'Przegląd', icon: BarChart3 },
    { id: 'organizations', label: 'Organizacje', icon: Users },
    { id: 'payments', label: 'Płatności', icon: CreditCard },
    { id: 'analytics', label: 'Analityka', icon: TrendingUp },
    { id: 'config', label: 'Konfiguracja', icon: Settings }
  ];

  const renderConfigTab = () => (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Konfiguracja API Autopay</h2>
        <div className="flex space-x-3">
          <button
            onClick={testApiConnection}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            <TestTube className="w-4 h-4" />
            <span>Testuj połączenie</span>
          </button>
          <button
            onClick={saveApiConfig}
            disabled={configLoading}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white rounded-lg transition-colors"
          >
            {configLoading ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            ) : (
              <Save className="w-4 h-4" />
            )}
            <span>Zapisz konfigurację</span>
          </button>
        </div>
      </div>

      {configSaved && (
        <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-5 h-5 text-green-400" />
            <p className="text-green-400">Konfiguracja została zapisana pomyślnie!</p>
          </div>
        </div>
      )}

      {/* Environment Toggle */}
      <div className="bg-gray-800 rounded-lg border border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Shield className="w-5 h-5 mr-2" />
          Środowisko
        </h3>
        
        <div className="space-y-4">
          <div className="flex items-center space-x-4">
            <label className="flex items-center space-x-2">
              <input
                type="radio"
                name="environment"
                value="sandbox"
                checked={apiConfig.autopay_environment === 'sandbox'}
                onChange={(e) => setApiConfig(prev => ({ ...prev, autopay_environment: e.target.value, is_live_mode: false }))}
                className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600"
              />
              <span className="text-gray-300">Sandbox (testowe)</span>
            </label>
            <label className="flex items-center space-x-2">
              <input
                type="radio"
                name="environment"
                value="production"
                checked={apiConfig.autopay_environment === 'production'}
                onChange={(e) => setApiConfig(prev => ({ ...prev, autopay_environment: e.target.value, is_live_mode: true }))}
                className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600"
              />
              <span className="text-gray-300">Produkcja (live)</span>
            </label>
          </div>
          
          {apiConfig.autopay_environment === 'production' && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
              <div className="flex items-center space-x-2">
                <AlertCircle className="w-5 h-5 text-red-400" />
                <p className="text-red-400 text-sm">
                  Uwaga! Środowisko produkcyjne będzie przetwarzać prawdziwe płatności.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* API Configuration */}
      <div className="bg-gray-800 rounded-lg border border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Key className="w-5 h-5 mr-2" />
          Dane dostępowe Autopay
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Klucz API *
            </label>
            <input
              type="password"
              value={apiConfig.autopay_api_key}
              onChange={(e) => setApiConfig(prev => ({ ...prev, autopay_api_key: e.target.value }))}
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="sk_test_..."
            />
            <p className="text-xs text-gray-400 mt-1">
              Klucz API otrzymany od Autopay
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Merchant ID *
            </label>
            <input
              type="text"
              value={apiConfig.autopay_merchant_id}
              onChange={(e) => setApiConfig(prev => ({ ...prev, autopay_merchant_id: e.target.value }))}
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="merchant_123456"
            />
            <p className="text-xs text-gray-400 mt-1">
              Identyfikator sprzedawcy w systemie Autopay
            </p>
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              URL Webhook *
            </label>
            <input
              type="url"
              value={apiConfig.webhook_url}
              onChange={(e) => setApiConfig(prev => ({ ...prev, webhook_url: e.target.value }))}
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="https://your-domain.com/api/payments/webhook"
            />
            <p className="text-xs text-gray-400 mt-1">
              URL do otrzymywania powiadomień o statusie płatności
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Kwota weryfikacji (PLN)
            </label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              max="10"
              value={apiConfig.verification_amount}
              onChange={(e) => setApiConfig(prev => ({ ...prev, verification_amount: parseFloat(e.target.value) }))}
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="text-xs text-gray-400 mt-1">
              Kwota przelewu weryfikacyjnego dla organizacji
            </p>
          </div>
        </div>
      </div>

      {/* Migration Guide */}
      <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-400 mb-4">
          Przejście na prawdziwe API Autopay
        </h3>
        
        <div className="space-y-4 text-sm text-blue-300">
          <div>
            <h4 className="font-medium text-blue-200 mb-2">1. Uzyskaj dostęp do Autopay:</h4>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Zarejestruj się na <a href="https://autopay.pl" target="_blank" rel="noopener noreferrer" className="underline">autopay.pl</a></li>
              <li>Przejdź proces weryfikacji biznesowej</li>
              <li>Otrzymaj klucze API (sandbox i production)</li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium text-blue-200 mb-2">2. Konfiguracja techniczna:</h4>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Wprowadź klucz API w polu powyżej</li>
              <li>Skonfiguruj webhook URL w panelu Autopay</li>
              <li>Przetestuj połączenie przyciskiem "Testuj połączenie"</li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium text-blue-200 mb-2">3. Zmiany w kodzie:</h4>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Zamień mock_autopay.py na prawdziwe wywołania API</li>
              <li>Dodaj obsługę webhook'ów od Autopay</li>
              <li>Zaimplementuj retry logic dla failed payments</li>
              <li>Dodaj logowanie transakcji</li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium text-blue-200 mb-2">4. Bezpieczeństwo:</h4>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Przechowuj klucze API w zmiennych środowiskowych</li>
              <li>Używaj HTTPS dla wszystkich połączeń</li>
              <li>Waliduj podpisy webhook'ów</li>
              <li>Implementuj rate limiting</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );

  // Rest of the component remains the same...
  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg border border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Łączne donacje</p>
              <p className="text-2xl font-bold text-white">
                {stats.total_donations?.toLocaleString() || 0} PLN
              </p>
              <p className="text-green-400 text-sm">+12% vs poprzedni miesiąc</p>
            </div>
            <DollarSign className="w-8 h-8 text-green-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg border border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Aktywne organizacje</p>
              <p className="text-2xl font-bold text-white">{stats.active_organizations || 0}</p>
              <p className="text-blue-400 text-sm">+2 nowe w tym miesiącu</p>
            </div>
            <Users className="w-8 h-8 text-blue-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg border border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Płatności dzisiaj</p>
              <p className="text-2xl font-bold text-white">{stats.payments_today || 0}</p>
              <p className="text-yellow-400 text-sm">
                {stats.payments_today_amount?.toLocaleString() || 0} PLN
              </p>
            </div>
            <CreditCard className="w-8 h-8 text-yellow-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg border border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">Średnia donacja</p>
              <p className="text-2xl font-bold text-white">
                {stats.average_donation?.toFixed(0) || 0} PLN
              </p>
              <p className="text-purple-400 text-sm">Ostatnie 30 dni</p>
            </div>
            <TrendingUp className="w-8 h-8 text-purple-400" />
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Payments */}
        <div className="bg-gray-800 rounded-lg border border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Ostatnie płatności</h3>
          <div className="space-y-3">
            {payments.slice(0, 5).map((payment) => (
              <div key={payment.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                <div>
                  <p className="text-white font-medium">{payment.amount} PLN</p>
                  <p className="text-gray-400 text-sm">{payment.donor_email}</p>
                </div>
                <div className="text-right">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    payment.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                    payment.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {payment.status}
                  </span>
                  <p className="text-gray-400 text-xs mt-1">
                    {new Date(payment.created_at).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Organizations */}
        <div className="bg-gray-800 rounded-lg border border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Top organizacje</h3>
          <div className="space-y-3">
            {organizations
              .sort((a, b) => b.collected_amount - a.collected_amount)
              .slice(0, 5)
              .map((org) => (
                <div key={org.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                  <div>
                    <p className="text-white font-medium">{org.name}</p>
                    <p className="text-gray-400 text-sm">{org.category}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-medium">{org.collected_amount.toLocaleString()} PLN</p>
                    <p className="text-gray-400 text-xs">
                      {((org.collected_amount / org.target_amount) * 100).toFixed(1)}% celu
                    </p>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderOrganizationsTab = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Zarządzanie organizacjami</h2>
        <button
          onClick={handleAddOrganization}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Dodaj organizację</span>
        </button>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Szukaj organizacji..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="all">Wszystkie statusy</option>
          <option value="active">Aktywne</option>
          <option value="pending">Oczekujące</option>
          <option value="suspended">Zawieszone</option>
        </select>
        <button
          onClick={fetchData}
          className="flex items-center space-x-2 px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Odśwież</span>
        </button>
      </div>

      {/* Organizations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredOrganizations.map((org) => (
          <div key={org.id} className="bg-gray-800 rounded-lg border border-gray-700 p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-white">{org.name}</h3>
                <p className="text-gray-400 text-sm">{org.category}</p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => window.open(`/donate/${org.id}`, '_blank')}
                  className="p-2 text-gray-400 hover:text-blue-400 transition-colors"
                  title="Podgląd"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleEditOrganization(org)}
                  className="p-2 text-gray-400 hover:text-yellow-400 transition-colors"
                  title="Edytuj"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDeleteOrganization(org.id)}
                  className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                  title="Usuń"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <p className="text-gray-300 text-sm mb-4 line-clamp-2">{org.description}</p>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Zebrano:</span>
                <span className="text-white font-medium">
                  {org.collected_amount.toLocaleString()} PLN
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Cel:</span>
                <span className="text-white">{org.target_amount.toLocaleString()} PLN</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${Math.min((org.collected_amount / org.target_amount) * 100, 100)}%`
                  }}
                ></div>
              </div>
              <div className="text-right">
                <span className="text-blue-400 text-sm font-medium">
                  {((org.collected_amount / org.target_amount) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderPaymentsTab = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Płatności</h2>
        <div className="flex space-x-3">
          <button className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors">
            <Download className="w-4 h-4" />
            <span>Eksportuj</span>
          </button>
          <button
            onClick={fetchData}
            className="flex items-center space-x-2 px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Odśwież</span>
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <input
          type="text"
          placeholder="Szukaj po email darczyńcy lub organizacji..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Payments Table */}
      <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  ID Płatności
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Darczyńca
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Kwota
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Metoda
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Data
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Akcje
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {filteredPayments.map((payment) => (
                <tr key={payment.id} className="hover:bg-gray-700">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    {payment.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                    {payment.donor_email}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-white font-medium">
                    {payment.amount} PLN
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    {payment.method}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      payment.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                      payment.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-red-500/20 text-red-400'
                    }`}>
                      {payment.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    {new Date(payment.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    <button className="text-blue-400 hover:text-blue-300">
                      Szczegóły
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderAnalyticsTab = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Analityka</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Payment Methods Chart */}
        <div className="bg-gray-800 rounded-lg border border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Płatności według metod</h3>
          <div className="space-y-4">
            {[
              { method: 'Karta płatnicza', count: 45, color: 'bg-blue-500' },
              { method: 'BLIK', count: 32, color: 'bg-green-500' },
              { method: 'Apple Pay', count: 18, color: 'bg-purple-500' },
              { method: 'Google Pay', count: 12, color: 'bg-yellow-500' }
            ].map((item) => (
              <div key={item.method} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${item.color}`}></div>
                  <span className="text-gray-300">{item.method}</span>
                </div>
                <span className="text-white font-medium">{item.count}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Payment Status Chart */}
        <div className="bg-gray-800 rounded-lg border border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Status płatności</h3>
          <div className="space-y-4">
            {[
              { status: 'Zakończone', count: 89, color: 'bg-green-500' },
              { status: 'W toku', count: 12, color: 'bg-yellow-500' },
              { status: 'Nieudane', count: 6, color: 'bg-red-500' }
            ].map((item) => (
              <div key={item.status} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${item.color}`}></div>
                  <span className="text-gray-300">{item.status}</span>
                </div>
                <span className="text-white font-medium">{item.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <h1 className="text-xl font-semibold text-white">Panel Administracyjny</h1>
            <button
              onClick={onLogout}
              className="flex items-center space-x-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Wyloguj</span>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-8">
            {tabs.map((tab) => {
              const TabIcon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-400'
                      : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-300'
                  }`}
                >
                  <TabIcon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'overview' && renderOverviewTab()}
        {activeTab === 'organizations' && renderOrganizationsTab()}
        {activeTab === 'payments' && renderPaymentsTab()}
        {activeTab === 'analytics' && renderAnalyticsTab()}
        {activeTab === 'config' && renderConfigTab()}
      </div>

      {/* Organization Modal */}
      {isModalOpen && (
        <OrganizationModal
          organization={editingOrganization}
          onSave={handleModalSave}
          onClose={() => setIsModalOpen(false)}
        />
      )}
    </div>
  );
};

export default AdminDashboard;

