import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Heart, Share2, QrCode, CreditCard, Smartphone, Apple, Chrome } from 'lucide-react';
import QRGenerator from '../components/QRGenerator';
import PaymentMethods from '../components/PaymentMethods';
import { mockOrganizations } from '../utils/mockData';

const DonationPage = () => {
  const { orgId } = useParams();
  const navigate = useNavigate();
  
  const [organization, setOrganization] = useState(null);
  const [selectedAmount, setSelectedAmount] = useState(null);
  const [customAmount, setCustomAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('');
  const [loading, setLoading] = useState(false);
  const [showQR, setShowQR] = useState(false);

  // Predefiniowane kwoty
  const predefinedAmounts = [10, 25, 50, 100, 200, 500];

  useEffect(() => {
    // Znajdź organizację na podstawie ID
    const org = mockOrganizations.find(o => o.id === orgId);
    if (org) {
      setOrganization(org);
    } else {
      // Przekieruj do strony błędu jeśli organizacja nie istnieje
      navigate('/error');
    }
  }, [orgId, navigate]);

  const handleAmountSelect = (amount) => {
    setSelectedAmount(amount);
    setCustomAmount('');
  };

  const handleCustomAmountChange = (value) => {
    setCustomAmount(value);
    setSelectedAmount(null);
  };

  const handlePaymentMethodSelect = (method) => {
    setSelectedMethod(method);
  };

  const handlePayment = async () => {
    const amount = selectedAmount || parseFloat(customAmount);
    
    if (!amount || amount <= 0) {
      alert('Proszę wybrać kwotę darowizny');
      return;
    }
    
    if (!selectedMethod) {
      alert('Proszę wybrać metodę płatności');
      return;
    }

    setLoading(true);
    
    try {
      // Symulacja płatności - 2 sekundy delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // 90% szans na sukces
      const success = Math.random() > 0.1;
      
      if (success) {
        // Przekieruj do strony sukcesu
        navigate(`/success?amount=${amount}&org=${organization.name}&method=${selectedMethod}`);
      } else {
        // Symulacja błędu płatności
        alert('Płatność nie powiodła się. Spróbuj ponownie.');
      }
    } catch (error) {
      alert('Wystąpił błąd podczas przetwarzania płatności');
    } finally {
      setLoading(false);
    }
  };

  const getProgressPercentage = () => {
    if (!organization) return 0;
    return Math.min((organization.collected_amount / organization.target_amount) * 100, 100);
  };

  const getCurrentUrl = () => {
    return window.location.href;
  };

  if (!organization) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Ładowanie...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <div className="bg-gray-800/50 backdrop-blur-sm border-b border-gray-700">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gradient-to-br from-primary-500 to-primary-600 rounded-xl flex items-center justify-center">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">{organization.name}</h1>
                <p className="text-gray-400">Wspieraj lokalną społeczność</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => setShowQR(!showQR)}
                className="p-3 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
                title="Pokaż kod QR"
              >
                <QrCode className="w-5 h-5 text-gray-300" />
              </button>
              <button
                onClick={() => navigator.share?.({ url: getCurrentUrl(), title: `Wspieraj ${organization.name}` })}
                className="p-3 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
                title="Udostępnij"
              >
                <Share2 className="w-5 h-5 text-gray-300" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Lewa kolumna - Informacje o zbiórce */}
          <div className="space-y-6">
            {/* Opis zbiórki */}
            <div className="card animate-fade-in">
              <h2 className="text-xl font-semibold text-white mb-4">O zbiórce</h2>
              <p className="text-gray-300 leading-relaxed mb-6">
                {organization.description}
              </p>
              
              {/* Progress bar */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Zebrano</span>
                  <span className="text-gray-400">Cel</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-primary-500 to-primary-400 h-3 rounded-full transition-all duration-1000 ease-out"
                    style={{ width: `${getProgressPercentage()}%` }}
                  ></div>
                </div>
                <div className="flex justify-between">
                  <span className="text-lg font-semibold text-white">
                    {organization.collected_amount.toLocaleString('pl-PL')} PLN
                  </span>
                  <span className="text-gray-400">
                    {organization.target_amount.toLocaleString('pl-PL')} PLN
                  </span>
                </div>
                <p className="text-sm text-gray-400">
                  {getProgressPercentage().toFixed(1)}% celu osiągnięte
                </p>
              </div>
            </div>

            {/* QR Code (jeśli pokazany) */}
            {showQR && (
              <div className="card animate-slide-up">
                <QRGenerator url={getCurrentUrl()} organizationName={organization.name} />
              </div>
            )}
          </div>

          {/* Prawa kolumna - Formularz płatności */}
          <div className="space-y-6">
            {/* Wybór kwoty */}
            <div className="card animate-fade-in">
              <h3 className="text-lg font-semibold text-white mb-4">Wybierz kwotę</h3>
              
              {/* Predefiniowane kwoty */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
                {predefinedAmounts.map((amount) => (
                  <button
                    key={amount}
                    onClick={() => handleAmountSelect(amount)}
                    className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                      selectedAmount === amount
                        ? 'border-primary-500 bg-primary-500/20 text-primary-400'
                        : 'border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500 hover:bg-gray-700'
                    }`}
                  >
                    <div className="text-lg font-semibold">{amount} PLN</div>
                  </button>
                ))}
              </div>

              {/* Kwota własna */}
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Lub wprowadź własną kwotę
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={customAmount}
                    onChange={(e) => handleCustomAmountChange(e.target.value)}
                    placeholder="0"
                    min="1"
                    className="input-field w-full pr-12 text-lg"
                  />
                  <span className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400">
                    PLN
                  </span>
                </div>
              </div>
            </div>

            {/* Metody płatności */}
            <div className="card animate-fade-in">
              <h3 className="text-lg font-semibold text-white mb-4">Metoda płatności</h3>
              <PaymentMethods 
                selectedMethod={selectedMethod}
                onMethodSelect={handlePaymentMethodSelect}
              />
            </div>

            {/* Przycisk płatności */}
            <button
              onClick={handlePayment}
              disabled={loading || (!selectedAmount && !customAmount) || !selectedMethod}
              className={`w-full py-4 px-6 rounded-lg font-semibold text-lg transition-all duration-200 ${
                loading || (!selectedAmount && !customAmount) || !selectedMethod
                  ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                  : 'btn-primary hover:scale-105 active:scale-95'
              }`}
            >
              {loading ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Przetwarzanie...</span>
                </div>
              ) : (
                `Wpłać ${selectedAmount || customAmount || '0'} PLN`
              )}
            </button>

            {/* Informacje o bezpieczeństwie */}
            <div className="text-center text-sm text-gray-400">
              <p>🔒 Płatność jest bezpieczna i szyfrowana</p>
              <p>Obsługiwane przez Autopay</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DonationPage;

