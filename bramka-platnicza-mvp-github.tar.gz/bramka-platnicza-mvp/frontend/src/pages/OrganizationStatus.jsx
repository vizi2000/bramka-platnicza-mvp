import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  XCircle,
  Shield,
  CreditCard,
  RefreshCw,
  Copy,
  ExternalLink,
  ArrowLeft
} from 'lucide-react';
import axios from 'axios';

const API_BASE = 'http://localhost:8000/api/org';

const OrganizationStatus = () => {
  const { registrationId } = useParams();
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [simulatingPayment, setSimulatingPayment] = useState(false);

  const fetchStatus = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_BASE}/registration/${registrationId}/status`);
      setStatus(response.data);
      setError(null);
    } catch (err) {
      setError(err.response?.data?.detail || 'Nie udało się pobrać statusu rejestracji');
    } finally {
      setLoading(false);
    }
  };

  const simulatePayment = async () => {
    try {
      setSimulatingPayment(true);
      const response = await axios.post(`${API_BASE}/registration/${registrationId}/simulate-payment`);
      
      // Refresh status after simulation
      setTimeout(() => {
        fetchStatus();
      }, 1000);
      
      alert(response.data.message);
    } catch (err) {
      alert(err.response?.data?.detail || 'Błąd symulacji płatności');
    } finally {
      setSimulatingPayment(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert('Skopiowano do schowka!');
  };

  useEffect(() => {
    if (registrationId) {
      fetchStatus();
      
      // Auto-refresh every 30 seconds if status is pending
      const interval = setInterval(() => {
        if (status?.status === 'verification_sent' || status?.status === 'pending') {
          fetchStatus();
        }
      }, 30000);
      
      return () => clearInterval(interval);
    }
  }, [registrationId]);

  const getStatusInfo = (statusValue) => {
    switch (statusValue) {
      case 'pending':
        return {
          icon: Clock,
          color: 'text-yellow-400',
          bgColor: 'bg-yellow-500/10',
          borderColor: 'border-yellow-500/20',
          title: 'Oczekuje na weryfikację',
          description: 'Twoja rejestracja została przyjęta i oczekuje na weryfikację.'
        };
      case 'verification_sent':
        return {
          icon: Shield,
          color: 'text-blue-400',
          bgColor: 'bg-blue-500/10',
          borderColor: 'border-blue-500/20',
          title: 'Oczekuje na przelew weryfikacyjny',
          description: 'Wykonaj przelew weryfikacyjny zgodnie z instrukcjami poniżej.'
        };
      case 'verified':
        return {
          icon: CheckCircle,
          color: 'text-green-400',
          bgColor: 'bg-green-500/10',
          borderColor: 'border-green-500/20',
          title: 'Organizacja zweryfikowana',
          description: 'Twoja organizacja została pomyślnie zweryfikowana i aktywowana!'
        };
      case 'rejected':
        return {
          icon: XCircle,
          color: 'text-red-400',
          bgColor: 'bg-red-500/10',
          borderColor: 'border-red-500/20',
          title: 'Rejestracja odrzucona',
          description: 'Niestety, Twoja rejestracja została odrzucona.'
        };
      case 'suspended':
        return {
          icon: AlertCircle,
          color: 'text-orange-400',
          bgColor: 'bg-orange-500/10',
          borderColor: 'border-orange-500/20',
          title: 'Konto zawieszone',
          description: 'Twoje konto zostało tymczasowo zawieszone.'
        };
      default:
        return {
          icon: Clock,
          color: 'text-gray-400',
          bgColor: 'bg-gray-500/10',
          borderColor: 'border-gray-500/20',
          title: 'Nieznany status',
          description: 'Status rejestracji jest nieznany.'
        };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Ładowanie statusu rejestracji...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-8 max-w-md w-full text-center">
          <XCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h1 className="text-xl font-bold text-white mb-2">Błąd</h1>
          <p className="text-gray-400 mb-6">{error}</p>
          <button
            onClick={() => window.location.href = '/'}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            Powrót do strony głównej
          </button>
        </div>
      </div>
    );
  }

  if (!status) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-8 max-w-md w-full text-center">
          <AlertCircle className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
          <h1 className="text-xl font-bold text-white mb-2">Nie znaleziono rejestracji</h1>
          <p className="text-gray-400 mb-6">
            Rejestracja o podanym ID nie została znaleziona.
          </p>
          <button
            onClick={() => window.location.href = '/org/register'}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            Zarejestruj organizację
          </button>
        </div>
      </div>
    );
  }

  const statusInfo = getStatusInfo(status.status);
  const StatusIcon = statusInfo.icon;

  return (
    <div className="min-h-screen bg-gray-900 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={() => window.history.back()}
            className="flex items-center text-gray-400 hover:text-white transition-colors mr-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Wstecz
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">Status rejestracji</h1>
            <p className="text-gray-400">ID: {registrationId}</p>
          </div>
        </div>

        {/* Status Card */}
        <div className={`${statusInfo.bgColor} ${statusInfo.borderColor} border rounded-xl p-6 mb-8`}>
          <div className="flex items-center mb-4">
            <div className={`w-12 h-12 ${statusInfo.bgColor} rounded-full flex items-center justify-center mr-4`}>
              <StatusIcon className={`w-6 h-6 ${statusInfo.color}`} />
            </div>
            <div>
              <h2 className={`text-xl font-semibold ${statusInfo.color}`}>
                {statusInfo.title}
              </h2>
              <p className="text-gray-300">{statusInfo.description}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-400">Data zgłoszenia:</span>
              <span className="text-white ml-2">
                {new Date(status.submitted_at).toLocaleDateString('pl-PL')}
              </span>
            </div>
            {status.verified_at && (
              <div>
                <span className="text-gray-400">Data weryfikacji:</span>
                <span className="text-white ml-2">
                  {new Date(status.verified_at).toLocaleDateString('pl-PL')}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Verification Payment Instructions */}
        {status.status === 'verification_sent' && status.verification_payment && (
          <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 mb-8">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
              <CreditCard className="w-5 h-5 mr-2 text-blue-400" />
              Instrukcje przelewu weryfikacyjnego
            </h3>

            <div className="bg-gray-700/50 rounded-lg p-4 mb-4">
              <div className="grid grid-cols-1 gap-3 text-sm">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Kwota:</span>
                  <div className="flex items-center">
                    <span className="text-white font-medium mr-2">
                      {status.verification_payment.amount.toFixed(2)} PLN
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Na konto:</span>
                  <div className="flex items-center">
                    <span className="text-white font-mono text-xs mr-2">
                      {status.verification_payment.autopay_account}
                    </span>
                    <button
                      onClick={() => copyToClipboard(status.verification_payment.autopay_account)}
                      className="text-blue-400 hover:text-blue-300 transition-colors"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Tytuł przelewu:</span>
                  <div className="flex items-center">
                    <span className="text-white font-mono text-xs mr-2 max-w-xs truncate">
                      {status.verification_payment.payment_title}
                    </span>
                    <button
                      onClick={() => copyToClipboard(status.verification_payment.payment_title)}
                      className="text-blue-400 hover:text-blue-300 transition-colors"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Z konta organizacji:</span>
                  <div className="flex items-center">
                    <span className="text-white font-mono text-xs mr-2">
                      {status.verification_payment.bank_account}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Numer referencyjny:</span>
                  <div className="flex items-center">
                    <span className="text-white font-medium mr-2">
                      {status.verification_payment.reference_number}
                    </span>
                    <button
                      onClick={() => copyToClipboard(status.verification_payment.reference_number)}
                      className="text-blue-400 hover:text-blue-300 transition-colors"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-4">
              <h4 className="text-blue-400 font-medium mb-2">Ważne informacje:</h4>
              <ul className="text-sm text-blue-300 space-y-1">
                <li>• Przelew musi być wykonany z konta bankowego organizacji</li>
                <li>• Tytuł przelewu musi być dokładnie taki jak podano</li>
                <li>• Weryfikacja może potrwać 1-3 dni robocze</li>
                <li>• Po weryfikacji otrzymasz email z potwierdzeniem</li>
              </ul>
            </div>

            {/* Demo: Simulate Payment Button */}
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 mb-4">
              <h4 className="text-yellow-400 font-medium mb-2">Demo - Symulacja płatności:</h4>
              <p className="text-sm text-yellow-300 mb-3">
                W wersji demo możesz zasymulować otrzymanie przelewu weryfikacyjnego.
              </p>
              <button
                onClick={simulatePayment}
                disabled={simulatingPayment}
                className="flex items-center space-x-2 px-4 py-2 bg-yellow-600 hover:bg-yellow-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors text-sm"
              >
                {simulatingPayment ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>Symulowanie...</span>
                  </>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4" />
                    <span>Symuluj otrzymanie przelewu</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Admin Notes */}
        {status.admin_notes && (
          <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 mb-8">
            <h3 className="text-lg font-semibold text-white mb-4">
              Uwagi administratora
            </h3>
            <p className="text-gray-300">{status.admin_notes}</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={fetchStatus}
            disabled={loading}
            className="flex items-center justify-center space-x-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Odśwież status</span>
          </button>

          {status.status === 'verified' && status.organization_id && (
            <button
              onClick={() => window.open(`/donate/${status.organization_id}`, '_blank')}
              className="flex items-center justify-center space-x-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Przejdź do strony donacji</span>
            </button>
          )}

          <button
            onClick={() => window.location.href = '/'}
            className="flex items-center justify-center space-x-2 px-6 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
          >
            <span>Powrót do strony głównej</span>
          </button>
        </div>

        {/* Auto-refresh indicator */}
        {(status.status === 'verification_sent' || status.status === 'pending') && (
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500">
              Status jest automatycznie odświeżany co 30 sekund
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrganizationStatus;

