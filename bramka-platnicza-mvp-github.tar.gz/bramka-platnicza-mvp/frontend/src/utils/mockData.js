// Mock data dla organizacji charytatywnych

export const mockOrganizations = [
  {
    id: 'parafia-sw-jana',
    name: 'Parafia św. Jana',
    description: 'Wspieraj naszą parafię w renowacji zabytkowego kościoła św. Jana. Twoja darowizna pomoże zachować dziedzictwo kulturowe naszej społeczności dla przyszłych pokoleń. Planujemy odnowić freski z XVIII wieku, wymienić organy oraz poprawić ogrzewanie świątyni.',
    logo_url: '/images/parafia-logo.png',
    target_amount: 50000,
    collected_amount: 23500,
    created_at: '2024-01-15',
    category: 'religia',
    location: 'Kraków',
    contact_email: 'kontakt@parafia-sw-jana.pl',
    website: 'https://parafia-sw-jana.pl'
  },
  {
    id: 'fundacja-pomocy-dzieciom',
    name: 'Fundacja Pomocy Dzieciom',
    description: 'Nasza fundacja od 15 lat pomaga dzieciom z rodzin w trudnej sytuacji materialnej. Organizujemy programy edukacyjne, zapewniamy posiłki w szkołach oraz wsparcie psychologiczne. Każda złotówka trafia bezpośrednio do potrzebujących dzieci w naszym regionie.',
    logo_url: '/images/fundacja-logo.png',
    target_amount: 100000,
    collected_amount: 67800,
    created_at: '2024-02-01',
    category: 'dzieci',
    location: 'Warszawa',
    contact_email: 'pomoc@fundacja-dzieci.org',
    website: 'https://fundacja-dzieci.org'
  },
  {
    id: 'schronisko-azyl',
    name: 'Schronisko "Azyl"',
    description: 'Schronisko dla bezdomnych zwierząt "Azyl" opiekuje się ponad 200 psami i kotami. Potrzebujemy środków na karmę, leczenie oraz rozbudowę schroniska. Każde zwierzę zasługuje na miłość i dom. Pomóż nam zapewnić im godne warunki do czasu znalezienia nowej rodziny.',
    logo_url: '/images/schronisko-logo.png',
    target_amount: 25000,
    collected_amount: 18200,
    created_at: '2024-01-20',
    category: 'zwierzeta',
    location: 'Gdańsk',
    contact_email: 'kontakt@schronisko-azyl.pl',
    website: 'https://schronisko-azyl.pl'
  }
];

// Mock data dla płatności
export const mockPayments = [
  {
    id: 'pay_001',
    organization_id: 'parafia-sw-jana',
    amount: 100,
    status: 'completed',
    method: 'card',
    donor_email: 'jan.kowalski@email.com',
    created_at: '2024-06-04T10:30:00Z',
    updated_at: '2024-06-04T10:31:00Z'
  },
  {
    id: 'pay_002',
    organization_id: 'fundacja-pomocy-dzieciom',
    amount: 50,
    status: 'completed',
    method: 'blik',
    donor_email: 'anna.nowak@email.com',
    created_at: '2024-06-04T09:15:00Z',
    updated_at: '2024-06-04T09:16:00Z'
  },
  {
    id: 'pay_003',
    organization_id: 'schronisko-azyl',
    amount: 200,
    status: 'pending',
    method: 'apple_pay',
    donor_email: 'piotr.wisniewski@email.com',
    created_at: '2024-06-04T11:45:00Z',
    updated_at: '2024-06-04T11:45:00Z'
  }
];

// Funkcje pomocnicze
export const getOrganizationById = (id) => {
  return mockOrganizations.find(org => org.id === id);
};

export const getPaymentsByOrganization = (organizationId) => {
  return mockPayments.filter(payment => payment.organization_id === organizationId);
};

export const getTotalDonations = () => {
  return mockOrganizations.reduce((total, org) => total + org.collected_amount, 0);
};

export const getTotalPayments = () => {
  return mockPayments.length;
};

export const getPaymentStats = () => {
  const completed = mockPayments.filter(p => p.status === 'completed').length;
  const pending = mockPayments.filter(p => p.status === 'pending').length;
  const failed = mockPayments.filter(p => p.status === 'failed').length;
  
  return { completed, pending, failed, total: mockPayments.length };
};

// Generowanie nowego ID płatności
export const generatePaymentId = () => {
  return `pay_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

// Formatowanie kwoty w PLN
export const formatCurrency = (amount) => {
  return new Intl.NumberFormat('pl-PL', {
    style: 'currency',
    currency: 'PLN'
  }).format(amount);
};

// Formatowanie daty
export const formatDate = (dateString) => {
  return new Intl.DateTimeFormat('pl-PL', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(new Date(dateString));
};

