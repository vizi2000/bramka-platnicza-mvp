import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { Download, Copy, Check } from 'lucide-react';

const QRGenerator = ({ url, organizationName }) => {
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [copied, setCopied] = useState(false);
  const canvasRef = useRef(null);

  useEffect(() => {
    generateQRCode();
  }, [url]);

  const generateQRCode = async () => {
    try {
      const canvas = canvasRef.current;
      if (!canvas) return;

      // Generuj QR code na canvas
      await QRCode.toCanvas(canvas, url, {
        width: 200,
        margin: 2,
        color: {
          dark: '#1f2937', // Ciemny kolor dla QR
          light: '#ffffff' // Białe tło
        },
        errorCorrectionLevel: 'M'
      });

      // Konwertuj canvas do data URL
      const dataUrl = canvas.toDataURL('image/png');
      setQrDataUrl(dataUrl);
    } catch (error) {
      console.error('Błąd generowania QR code:', error);
    }
  };

  const handleDownload = () => {
    if (!qrDataUrl) return;

    const link = document.createElement('a');
    link.download = `qr-${organizationName.toLowerCase().replace(/\s+/g, '-')}.png`;
    link.href = qrDataUrl;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Błąd kopiowania URL:', error);
      // Fallback dla starszych przeglądarek
      const textArea = document.createElement('textarea');
      textArea.value = url;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="text-center space-y-4">
      <h3 className="text-lg font-semibold text-white">Kod QR do udostępnienia</h3>
      
      {/* QR Code */}
      <div className="flex justify-center">
        <div className="bg-white p-4 rounded-xl shadow-lg">
          <canvas
            ref={canvasRef}
            className="block"
            style={{ imageRendering: 'pixelated' }}
          />
        </div>
      </div>

      {/* Nazwa organizacji */}
      <p className="text-sm text-gray-400">
        Kod QR dla: <span className="text-white font-medium">{organizationName}</span>
      </p>

      {/* Przyciski akcji */}
      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <button
          onClick={handleDownload}
          disabled={!qrDataUrl}
          className="flex items-center justify-center space-x-2 px-4 py-2 bg-primary-600 hover:bg-primary-700 disabled:bg-gray-700 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Pobierz QR</span>
        </button>
        
        <button
          onClick={handleCopyUrl}
          className={`flex items-center justify-center space-x-2 px-4 py-2 rounded-lg transition-all ${
            copied
              ? 'bg-green-600 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
          }`}
        >
          {copied ? (
            <>
              <Check className="w-4 h-4" />
              <span>Skopiowano!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              <span>Kopiuj link</span>
            </>
          )}
        </button>
      </div>

      {/* URL do skopiowania */}
      <div className="mt-4 p-3 bg-gray-800 rounded-lg border border-gray-700">
        <p className="text-xs text-gray-400 mb-2">Link do udostępnienia:</p>
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={url}
            readOnly
            className="flex-1 bg-gray-700 text-gray-300 text-sm px-3 py-2 rounded border border-gray-600 focus:outline-none"
          />
          <button
            onClick={handleCopyUrl}
            className="p-2 bg-gray-700 hover:bg-gray-600 rounded transition-colors"
            title="Kopiuj link"
          >
            {copied ? (
              <Check className="w-4 h-4 text-green-400" />
            ) : (
              <Copy className="w-4 h-4 text-gray-400" />
            )}
          </button>
        </div>
      </div>

      {/* Instrukcje użycia */}
      <div className="text-left space-y-2 text-sm text-gray-400">
        <h4 className="font-medium text-white">Jak używać kodu QR:</h4>
        <ul className="space-y-1 list-disc list-inside">
          <li>Wydrukuj kod QR i umieść w widocznym miejscu</li>
          <li>Udostępnij w mediach społecznościowych</li>
          <li>Dodaj do materiałów promocyjnych</li>
          <li>Skanowanie kodem przeniesie bezpośrednio na stronę wpłat</li>
        </ul>
      </div>
    </div>
  );
};

export default QRGenerator;

