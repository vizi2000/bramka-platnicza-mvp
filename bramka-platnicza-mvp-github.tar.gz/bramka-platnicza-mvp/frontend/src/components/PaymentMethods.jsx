import React from 'react';
import { CreditCard, Smartphone, Apple, Chrome } from 'lucide-react';

const PaymentMethods = ({ selectedMethod, onMethodSelect }) => {
  const paymentMethods = [
    {
      id: 'card',
      name: 'Karta płatnicza',
      description: 'Visa, Mastercard, Maestro',
      icon: CreditCard,
      color: 'from-blue-500 to-blue-600',
      available: true
    },
    {
      id: 'blik',
      name: 'BLIK',
      description: 'Szybka płatność mobilna',
      icon: Smartphone,
      color: 'from-green-500 to-green-600',
      available: true
    },
    {
      id: 'apple_pay',
      name: 'Apple Pay',
      description: 'Płać iPhone lub Apple Watch',
      icon: Apple,
      color: 'from-gray-700 to-gray-800',
      available: true
    },
    {
      id: 'google_pay',
      name: 'Google Pay',
      description: 'Płać telefonem Android',
      icon: Chrome,
      color: 'from-red-500 to-yellow-500',
      available: true
    }
  ];

  return (
    <div className="space-y-3">
      {paymentMethods.map((method) => {
        const IconComponent = method.icon;
        const isSelected = selectedMethod === method.id;
        
        return (
          <button
            key={method.id}
            onClick={() => onMethodSelect(method.id)}
            disabled={!method.available}
            className={`w-full p-4 rounded-lg border-2 transition-all duration-200 text-left ${
              isSelected
                ? 'border-primary-500 bg-primary-500/20'
                : method.available
                ? 'border-gray-600 bg-gray-700/50 hover:border-gray-500 hover:bg-gray-700'
                : 'border-gray-700 bg-gray-800/50 opacity-50 cursor-not-allowed'
            }`}
          >
            <div className="flex items-center space-x-4">
              {/* Ikona metody płatności */}
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${method.color} flex items-center justify-center flex-shrink-0`}>
                <IconComponent className="w-6 h-6 text-white" />
              </div>
              
              {/* Informacje o metodzie */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className={`font-semibold ${isSelected ? 'text-primary-400' : 'text-white'}`}>
                    {method.name}
                  </h4>
                  {isSelected && (
                    <div className="w-5 h-5 bg-primary-500 rounded-full flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                  )}
                </div>
                <p className="text-sm text-gray-400 mt-1">
                  {method.description}
                </p>
                {!method.available && (
                  <p className="text-xs text-red-400 mt-1">
                    Niedostępne
                  </p>
                )}
              </div>
            </div>
          </button>
        );
      })}
      
      {/* Informacja o bezpieczeństwie */}
      <div className="mt-4 p-3 bg-gray-800/50 rounded-lg border border-gray-700">
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-green-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          </div>
          <div>
            <h5 className="text-sm font-medium text-white">Bezpieczne płatności</h5>
            <p className="text-xs text-gray-400 mt-1">
              Wszystkie płatności są szyfrowane i przetwarzane przez licencjonowanego dostawcę płatności Autopay.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentMethods;

