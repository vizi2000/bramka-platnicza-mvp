import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import DonationPage from './pages/DonationPage';
import SuccessPage from './pages/SuccessPage';
import ErrorPage from './pages/ErrorPage';
import AdminRoute from './pages/AdminRoute';
import OrganizationRegistration from './pages/OrganizationRegistration';
import OrganizationStatus from './pages/OrganizationStatus';
import './index.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Strona główna */}
          <Route path="/" element={<HomePage />} />
          
          {/* Strona płatności dla konkretnej organizacji */}
          <Route path="/donate/:orgId" element={<DonationPage />} />
          
          {/* Strona sukcesu po płatności */}
          <Route path="/success" element={<SuccessPage />} />
          
          {/* Strona błędu */}
          <Route path="/error" element={<ErrorPage />} />
          
          {/* Panel administracyjny */}
          <Route path="/admin" element={<AdminRoute />} />
          
          {/* Rejestracja organizacji */}
          <Route path="/org/register" element={<OrganizationRegistration />} />
          
          {/* Status rejestracji organizacji */}
          <Route path="/org/status/:registrationId" element={<OrganizationStatus />} />
          
          {/* Catch-all route dla nieistniejących stron */}
          <Route path="*" element={<ErrorPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

