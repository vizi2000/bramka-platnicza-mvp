# 🚀 Bramka Płatnicza MVP

**Nowoczesna platforma do zbierania donacji online dla organizacji charytatywnych**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![React](https://img.shields.io/badge/React-18.0-blue.svg)](https://reactjs.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.104-green.svg)](https://fastapi.tiangolo.com/)
[![Python](https://img.shields.io/badge/Python-3.11-blue.svg)](https://python.org/)

## 📋 Spis treści

- [Opis projektu](#opis-projektu)
- [Funkcjonalności](#funkcjonalności)
- [Technologie](#technologie)
- [Instalacja](#instalacja)
- [Uruchomienie](#uruchomienie)
- [Konfiguracja](#konfiguracja)
- [API Documentation](#api-documentation)
- [Struktura projektu](#struktura-projektu)
- [Rozwój](#rozwój)
- [Licencja](#licencja)

## 🎯 Opis projektu

Bramka Płatnicza MVP to kompletna platforma umożliwiająca organizacjom charytatywnym zbieranie donacji online. System oferuje intuicyjny interfejs dla darczyńców, zaawansowany panel administracyjny oraz możliwość integracji z systemem płatności Autopay.

### Kluczowe zalety:
- **Responsywny design** - działa na wszystkich urządzeniach
- **Bezpieczne płatności** - integracja z Autopay
- **Panel administracyjny** - pełne zarządzanie organizacjami i płatnościami
- **Rejestracja organizacji** - samoobsługowy system weryfikacji
- **QR codes** - łatwe udostępnianie zbiórek
- **Real-time analytics** - statystyki w czasie rzeczywistym

## ✨ Funkcjonalności

### 🏠 Strona główna
- Lista aktywnych organizacji charytatywnych
- Globalne statystyki platform
- Responsywny design z ciemnym motywem

### 💳 System płatności
- Wybór kwot donacji (10, 25, 50, 100, 200, 500 PLN + custom)
- Metody płatności: karta, BLIK, Apple Pay, Google Pay
- Generator kodów QR do udostępniania
- Progress bar pokazujący postęp zbiórki
- Funkcja udostępniania (Web Share API)

### 🏢 Rejestracja organizacji
- 5-krokowy formularz rejestracji
- Weryfikacja przez przelew 1 zł
- Real-time monitoring statusu
- Automatyczne generowanie instrukcji płatności

### 🔧 Panel administracyjny
- **Przegląd** - karty statystyk, ostatnie płatności, top organizacje
- **Organizacje** - CRUD operations, progress tracking
- **Płatności** - tabela z filtrowaniem i wyszukiwaniem
- **Analityka** - wykresy metod płatności i statusów
- **Konfiguracja** - ustawienia API Autopay

### 📊 Analityka
- Statystyki w czasie rzeczywistym
- Wykresy płatności według metod
- Ranking organizacji
- Monitoring statusów płatności

## 🛠 Technologie

### Frontend
- **React 18** - nowoczesny framework UI
- **Vite** - szybki bundler i dev server
- **Tailwind CSS** - utility-first styling
- **React Router DOM** - routing
- **Axios** - HTTP client
- **Lucide React** - ikony
- **QRCode.js** - generowanie kodów QR

### Backend
- **FastAPI** - nowoczesne Python API
- **Pydantic** - walidacja danych
- **Uvicorn** - ASGI server
- **Python-JOSE** - JWT handling
- **JSON Storage** - lekka baza danych dla MVP

### DevOps
- **Docker** - konteneryzacja
- **Docker Compose** - orchestracja
- **GitHub Actions** - CI/CD (opcjonalnie)

## 📦 Instalacja

### Wymagania
- **Node.js** 18+ 
- **Python** 3.11+
- **Docker** (opcjonalnie)
- **Git**

### Klonowanie repozytorium
```bash
git clone https://github.com/your-username/bramka-platnicza-mvp.git
cd bramka-platnicza-mvp
```

### Opcja 1: Docker (Rekomendowane)
```bash
# Uruchomienie całej aplikacji
docker-compose up --build

# Aplikacja będzie dostępna na:
# Frontend: http://localhost:5173
# Backend: http://localhost:8000
# API Docs: http://localhost:8000/docs
```

### Opcja 2: Manualna instalacja

#### Backend
```bash
cd backend
pip install -r requirements.txt
python main.py
```

#### Frontend
```bash
cd frontend
npm install
npm run dev
```

## 🚀 Uruchomienie

### Szybki start
1. **Uruchom aplikację** (Docker lub manualnie)
2. **Otwórz frontend**: http://localhost:5173
3. **Sprawdź API**: http://localhost:8000/docs
4. **Panel admin**: http://localhost:5173/admin (admin/admin123)

### Testowanie funkcjonalności

#### Test płatności
1. Przejdź na stronę główną
2. Wybierz organizację (np. "Parafia św. Jana")
3. Wybierz kwotę i metodę płatności
4. Kliknij "Wpłać" i obserwuj proces

#### Test rejestracji organizacji
1. Kliknij "Zarejestruj organizację"
2. Wypełnij 5-krokowy formularz
3. Otrzymaj instrukcje weryfikacji
4. Sprawdź status na dedykowanej stronie

#### Test panelu administracyjnego
1. Przejdź do http://localhost:5173/admin
2. Zaloguj się: admin / admin123
3. Eksploruj wszystkie zakładki
4. Przetestuj dodawanie/edycję organizacji

## ⚙️ Konfiguracja

### Zmienne środowiskowe
Skopiuj `.env.example` do `.env` i dostosuj:

```bash
# Backend
DATABASE_URL=sqlite:///./app.db
SECRET_KEY=your-secret-key-here
AUTOPAY_API_KEY=your-autopay-api-key
AUTOPAY_ENVIRONMENT=sandbox

# Frontend
VITE_API_BASE_URL=http://localhost:8000/api
```

### Konfiguracja Autopay
1. Przejdź do panelu admin → Konfiguracja
2. Wprowadź klucz API Autopay
3. Ustaw Merchant ID
4. Skonfiguruj webhook URL
5. Przetestuj połączenie

### Przejście na produkcję
1. **Zmień środowisko** na "production" w panelu admin
2. **Wprowadź prawdziwy klucz API** Autopay
3. **Skonfiguruj webhook** w panelu Autopay
4. **Zastąp mock_autopay.py** prawdziwymi wywołaniami API
5. **Dodaj HTTPS** i certyfikaty SSL

## 📚 API Documentation

### Główne endpointy

#### Organizacje
- `GET /api/organizations` - Lista organizacji
- `POST /api/organizations` - Dodaj organizację (admin)
- `GET /api/organizations/{id}` - Szczegóły organizacji
- `PUT /api/organizations/{id}` - Edytuj organizację (admin)
- `DELETE /api/organizations/{id}` - Usuń organizację (admin)

#### Płatności
- `POST /api/payments/initiate` - Inicjuj płatność
- `GET /api/payments/{id}/status` - Status płatności
- `POST /api/payments/webhook` - Webhook Autopay

#### Rejestracja organizacji
- `POST /api/org/register` - Rejestracja organizacji
- `GET /api/org/registration/{id}/status` - Status rejestracji
- `POST /api/org/registration/{id}/simulate-payment` - Symulacja płatności

#### Administracja
- `GET /api/admin/config` - Konfiguracja API
- `PUT /api/admin/config` - Aktualizuj konfigurację
- `POST /api/admin/test-autopay` - Test połączenia Autopay

### Swagger UI
Pełna dokumentacja API dostępna pod: http://localhost:8000/docs

## 📁 Struktura projektu

```
bramka-platnicza-mvp/
├── 📁 frontend/                 # React aplikacja
│   ├── 📁 src/
│   │   ├── 📁 components/       # Komponenty React
│   │   ├── 📁 pages/           # Strony aplikacji
│   │   ├── 📁 utils/           # Utilities i helpers
│   │   ├── App.jsx             # Główny komponent
│   │   └── main.jsx            # Entry point
│   ├── package.json            # Dependencies
│   ├── tailwind.config.js      # Konfiguracja Tailwind
│   └── vite.config.js          # Konfiguracja Vite
├── 📁 backend/                  # FastAPI aplikacja
│   ├── 📁 app/
│   │   ├── 📁 routes/          # API endpoints
│   │   ├── 📁 data/            # JSON storage
│   │   ├── 📁 utils/           # Backend utilities
│   │   └── models.py           # Pydantic models
│   ├── main.py                 # FastAPI app
│   └── requirements.txt        # Python dependencies
├── 📁 docs/                     # Dokumentacja
├── docker-compose.yml          # Docker orchestration
├── .gitignore                  # Git ignore rules
└── README.md                   # Ten plik
```

## 🔄 Rozwój

### Roadmap
- [ ] **Prawdziwa integracja Autopay** - zastąpienie mock API
- [ ] **Dashboard organizacji** - panel dla organizacji
- [ ] **Email notifications** - powiadomienia o płatnościach
- [ ] **Eksport danych** - CSV/PDF reports
- [ ] **Social media integration** - udostępnianie zbiórek
- [ ] **Mobile app** - React Native aplikacja
- [ ] **Advanced analytics** - szczegółowe raporty
- [ ] **Multi-language support** - internacjonalizacja

### Jak kontrybuować
1. Fork repozytorium
2. Stwórz branch feature (`git checkout -b feature/amazing-feature`)
3. Commit zmiany (`git commit -m 'Add amazing feature'`)
4. Push do branch (`git push origin feature/amazing-feature`)
5. Otwórz Pull Request

### Zgłaszanie błędów
Użyj [GitHub Issues](https://github.com/your-username/bramka-platnicza-mvp/issues) do zgłaszania błędów lub propozycji funkcjonalności.

## 📄 Licencja

Ten projekt jest licencjonowany na licencji MIT - zobacz plik [LICENSE](LICENSE) dla szczegółów.

## 🤝 Wsparcie

- **Email**: support@bramka-platnicza.pl
- **GitHub Issues**: [Zgłoś problem](https://github.com/your-username/bramka-platnicza-mvp/issues)
- **Dokumentacja**: [Wiki](https://github.com/your-username/bramka-platnicza-mvp/wiki)

## 🙏 Podziękowania

- [Autopay](https://autopay.pl) - system płatności
- [React](https://reactjs.org/) - framework frontend
- [FastAPI](https://fastapi.tiangolo.com/) - framework backend
- [Tailwind CSS](https://tailwindcss.com/) - styling
- [Lucide](https://lucide.dev/) - ikony

---

**Stworzono z ❤️ przez zespół Bramka Płatnicza**

