# 🚀 Przewodnik wdrożenia

## Deployment na Vercel (Frontend)

### 1. Przygotowanie
```bash
# Build aplikacji
cd frontend
npm run build
```

### 2. Konfiguracja Vercel
```json
{
  "version": 2,
  "builds": [
    {
      "src": "package.json",
      "use": "@vercel/static-build",
      "config": {
        "distDir": "dist"
      }
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "/index.html"
    }
  ],
  "env": {
    "VITE_API_BASE_URL": "https://your-backend-url.com/api"
  }
}
```

### 3. Deploy
```bash
# Zainstaluj Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
```

## Deployment na Railway (Backend)

### 1. Przygotowanie
Stwórz `railway.json`:
```json
{
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "python main.py",
    "healthcheckPath": "/health"
  }
}
```

### 2. Zmienne środowiskowe
W panelu Railway ustaw:
- `DATABASE_URL`
- `SECRET_KEY`
- `AUTOPAY_API_KEY`
- `AUTOPAY_MERCHANT_ID`

### 3. Deploy
```bash
# Zainstaluj Railway CLI
npm install -g @railway/cli

# Login i deploy
railway login
railway deploy
```

## Deployment na Heroku

### Frontend (Static)
```bash
# Stwórz aplikację
heroku create your-app-frontend

# Deploy
git subtree push --prefix frontend heroku main
```

### Backend
```bash
# Stwórz aplikację
heroku create your-app-backend

# Dodaj zmienne środowiskowe
heroku config:set SECRET_KEY=your-secret-key
heroku config:set AUTOPAY_API_KEY=your-api-key

# Deploy
git subtree push --prefix backend heroku main
```

## Docker Production

### 1. Production Dockerfile (Backend)
```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "4"]
```

### 2. Production Dockerfile (Frontend)
```dockerfile
FROM node:18-alpine as build

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf

EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### 3. Docker Compose Production
```yaml
version: '3.8'

services:
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile.prod
    ports:
      - "80:80"
    depends_on:
      - backend

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile.prod
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/bramka
      - SECRET_KEY=${SECRET_KEY}
      - AUTOPAY_API_KEY=${AUTOPAY_API_KEY}
    depends_on:
      - db

  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=bramka
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

## Konfiguracja domeny i SSL

### 1. Cloudflare
- Dodaj domenę do Cloudflare
- Ustaw DNS records:
  - `A` record: `@` → IP serwera
  - `CNAME` record: `www` → `your-domain.com`
  - `CNAME` record: `api` → `your-backend-url.com`

### 2. Nginx (jeśli używasz VPS)
```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Monitoring i logowanie

### 1. Sentry (Error tracking)
```bash
# Install
npm install @sentry/react @sentry/tracing

# Configure
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: "YOUR_SENTRY_DSN",
  environment: "production"
});
```

### 2. LogRocket (Session replay)
```bash
npm install logrocket
```

### 3. Google Analytics
```html
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_TRACKING_ID"></script>
```

## Backup i bezpieczeństwo

### 1. Automatyczne backupy
```bash
#!/bin/bash
# backup.sh
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump $DATABASE_URL > backup_$DATE.sql
aws s3 cp backup_$DATE.sql s3://your-backup-bucket/
```

### 2. Security headers
```python
# FastAPI middleware
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware

app.add_middleware(
    TrustedHostMiddleware, 
    allowed_hosts=["your-domain.com", "*.your-domain.com"]
)
```

## CI/CD z GitHub Actions

### 1. Frontend deployment
```yaml
# .github/workflows/frontend.yml
name: Deploy Frontend

on:
  push:
    branches: [main]
    paths: ['frontend/**']

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: cd frontend && npm ci
      - run: cd frontend && npm run build
      - uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
          working-directory: ./frontend
```

### 2. Backend deployment
```yaml
# .github/workflows/backend.yml
name: Deploy Backend

on:
  push:
    branches: [main]
    paths: ['backend/**']

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - run: cd backend && pip install -r requirements.txt
      - run: cd backend && python -m pytest
      - uses: akhileshns/heroku-deploy@v3.12.12
        with:
          heroku_api_key: ${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: "your-backend-app"
          heroku_email: "your-email@example.com"
          appdir: "backend"
```

